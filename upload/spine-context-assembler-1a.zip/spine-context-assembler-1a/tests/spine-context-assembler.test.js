import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  SpineContextAssembler,
  assembleSpineContext,
  verifySpineContextAssembly,
} from "../packages/core/src/spine-context-assembler.js";
import {
  assembleSpineContextWithFate,
  evaluateSpineContextAuthority,
} from "../packages/core/src/spine-context-fate-gate.js";
import {
  buildSpineContextReceiptBody,
  sealSpineContextReceipt,
} from "../packages/receipts/src/spine-context-receipt.js";

function fixture() {
  return {
    schema: "bizra.dema.ultra_micro_spec_graph.v0.1",
    nodes: [
      {
        id: "root",
        kind: "ARCHITECTURE",
        title: "Root architecture",
        public_contract: { invariants: ["human sovereignty"] },
        implementation_design: { secret: "never include ancestor internals" },
      },
      {
        id: "service",
        kind: "ARCHITECTURE",
        title: "Service boundary",
        architectural_parents: ["root"],
        public_contract: { inputs: ["mission"], outputs: ["proposal"] },
        implementation_design: { internal: "hidden" },
      },
      {
        id: "target",
        kind: "MICRO_SPEC",
        title: "Target micro-spec",
        architectural_parents: ["service"],
        dependencies: ["depB", "depA"],
        public_contract: {
          inputs: ["x"],
          outputs: ["y"],
          invariants: ["deterministic"],
        },
        implementation_design: { algorithm: "bounded" },
      },
      {
        id: "depA",
        kind: "DEPENDENCY",
        title: "Dependency A",
        public_signature: { inputs: ["a"], outputs: ["b"] },
        implementation_design: { secret: "A body" },
      },
      {
        id: "depB",
        kind: "DEPENDENCY",
        title: "Dependency B",
        public_contract: {
          signature: { inputs: ["m"], outputs: ["n"], errors: ["E_B"] },
        },
        implementation_design: { secret: "B body" },
      },
      {
        id: "unrelated",
        kind: "MICRO_SPEC",
        public_contract: { inputs: [], outputs: [] },
        implementation_design: { huge: "should never enter context" },
      },
    ],
  };
}

const request = {
  target_spec_id: "target",
  phase: "IMPLEMENT",
  max_nodes: 16,
  max_context_bytes: 65536,
};

describe("SpineContextAssembler", () => {
  it("assembles target + architectural ancestors + immediate public dependency signatures only", () => {
    const r = assembleSpineContext(fixture(), request);
    assert.equal(r.ok, true);
    assert.deepEqual(r.context.architectural_ancestors.map((x) => x.id), ["root", "service"]);
    assert.deepEqual(r.context.immediate_dependencies.map((x) => x.id), ["depA", "depB"]);
    assert.deepEqual(r.included_node_ids, ["depA", "depB", "root", "service", "target"]);
    assert.equal(r.excluded_node_count, 1);
    assert.equal(r.context.target.implementation_design.algorithm, "bounded");
  });

  it("never exposes dependency or ancestor implementation bodies", () => {
    const r = assembleSpineContext(fixture(), request);
    assert.equal("implementation_design" in r.context.architectural_ancestors[0], false);
    assert.equal("implementation_design" in r.context.immediate_dependencies[0], false);
    assert.equal(JSON.stringify(r).includes("A body"), false);
    assert.equal(JSON.stringify(r).includes("B body"), false);
    assert.equal(JSON.stringify(r).includes("ancestor internals"), false);
  });

  it("SPECIFY phase omits target implementation design", () => {
    const r = assembleSpineContext(fixture(), { ...request, phase: "SPECIFY" });
    assert.equal(r.ok, true);
    assert.equal("implementation_design" in r.context.target, false);
  });

  it("is deterministic under graph node reordering", () => {
    const a = fixture();
    const b = fixture();
    b.nodes = [...b.nodes].reverse();
    const x = assembleSpineContext(a, request);
    const y = assembleSpineContext(b, request);
    assert.equal(x.ok, true);
    assert.equal(y.ok, true);
    assert.equal(x.spine_hash, y.spine_hash);
    assert.deepEqual(x, y);
  });

  it("rejects dangling references", () => {
    const g = fixture();
    g.nodes.find((x) => x.id === "target").dependencies.push("missing");
    const r = assembleSpineContext(g, request);
    assert.equal(r.ok, false);
    assert.ok(r.blocked_by.some((x) => x.includes("dangling_dependency")));
  });

  it("rejects graph cycles", () => {
    const g = fixture();
    g.nodes.find((x) => x.id === "root").architectural_parents = ["target"];
    const r = assembleSpineContext(g, request);
    assert.equal(r.ok, false);
    assert.ok(r.blocked_by.some((x) => x.startsWith("graph_cycle:")));
  });

  it("rejects dependency without a public signature", () => {
    const g = fixture();
    const dep = g.nodes.find((x) => x.id === "depA");
    delete dep.public_signature;
    const r = assembleSpineContext(g, request);
    assert.equal(r.ok, false);
    assert.ok(r.blocked_by.includes("dependency_public_signature_missing:depA"));
  });

  it("fails closed instead of truncating when the context budget is exceeded", () => {
    const r = assembleSpineContext(fixture(), { ...request, max_context_bytes: 20 });
    assert.equal(r.ok, false);
    assert.ok(r.blocked_by.some((x) => x.startsWith("context_budget_exceeded:")));
  });

  it("verifier rejects a forged-and-rehashed-looking semantic change by re-deriving from graph", () => {
    const good = assembleSpineContext(fixture(), request);
    const forged = structuredClone(good);
    forged.context.target.title = "forged";
    const v = verifySpineContextAssembly({ graph: fixture(), request, assembly: forged });
    assert.equal(v.ok, false);
    assert.ok(v.blocked_by.includes("assembly_semantic_mismatch"));
  });

  it("class wrapper preserves the same deterministic contract", () => {
    const asm = new SpineContextAssembler({ maxNodes: 16, maxContextBytes: 65536 });
    const r = asm.assemble(fixture(), { target_spec_id: "target", phase: "PLAN" });
    assert.equal(r.ok, true);
    assert.equal(asm.verify(fixture(), { target_spec_id: "target", phase: "PLAN" }, r).ok, true);
  });
});

describe("FATE integration", () => {
  it("L0-L2 permit read-only context assembly but never execution", () => {
    for (const level of ["L0", "L1", "L2"]) {
      const r = evaluateSpineContextAuthority({ autonomy_level: level });
      assert.equal(r.permitted_for_context_assembly, true);
      assert.equal(r.execution_authorized, false);
      assert.equal(r.capability_granted, false);
      assert.equal(r.authority_delta, 0);
    }
  });

  it("L3 fails closed because this pure adapter cannot prompt the human", () => {
    const r = evaluateSpineContextAuthority({ autonomy_level: "L3" });
    assert.equal(r.permitted_for_context_assembly, false);
    assert.equal(r.verdict, "BLOCK_HUMAN_CONFIRMATION_REQUIRED");
  });

  it("L4 routes through exact-string canonical FATE consent", () => {
    const bad = evaluateSpineContextAuthority({
      autonomy_level: "L4",
      phrase: "almost",
      required_phrase: "EXACT",
    });
    const good = evaluateSpineContextAuthority({
      autonomy_level: "L4",
      phrase: "EXACT",
      required_phrase: "EXACT",
    });
    assert.equal(bad.permitted_for_context_assembly, false);
    assert.equal(good.permitted_for_context_assembly, true);
    assert.equal(good.fate_invoked, true);
    assert.equal(good.execution_authorized, false);
  });

  it("L5 and unknown levels refuse", () => {
    assert.equal(evaluateSpineContextAuthority({ autonomy_level: "L5" }).permitted_for_context_assembly, false);
    assert.equal(evaluateSpineContextAuthority({ autonomy_level: "L99" }).permitted_for_context_assembly, false);
  });

  it("blocked FATE prevents assembly", () => {
    const r = assembleSpineContextWithFate({
      graph: fixture(),
      request,
      autonomy_level: "L4",
      phrase: "NO",
      required_phrase: "YES",
    });
    assert.equal(r.ok, false);
    assert.equal(r.assembly, null);
  });
});

describe("Truth Spine receipt sealing", () => {
  it("builds a narrow receipt body that never claims execution authority", () => {
    const assembly = assembleSpineContext(fixture(), request);
    const fate = evaluateSpineContextAuthority({ autonomy_level: "L0" });
    const body = buildSpineContextReceiptBody({ assembly, fate });
    assert.equal(body.spine_hash, assembly.spine_hash);
    assert.equal(body.authority_delta, 0);
    assert.equal(body.fate.execution_authorized, false);
    assert.equal(body.boundary.code_mutation, false);
    assert.equal(body.boundary.runtime_execution, false);
  });

  it("re-verifies against graph before calling the canonical appender", async () => {
    const graph = fixture();
    const assembly = assembleSpineContext(graph, request);
    const fate = evaluateSpineContextAuthority({ autonomy_level: "L0" });
    const calls = [];
    const appendReceipt = async (args) => {
      calls.push(args);
      return {
        appended: true,
        receipt: { receipt_id: "receipt-1" },
        head: "receipt-1",
        length: 1,
      };
    };
    const r = await sealSpineContextReceipt({
      graph,
      request,
      assembly,
      fate,
      demaHome: "/tmp/dema-test",
      now: new Date("2026-08-29T00:00:00Z"),
      appendReceipt,
      receiptConsentPhrase: "APPEND CANONICAL RECEIPT",
    });
    assert.equal(r.sealed, true);
    assert.equal(r.receipt_id, "receipt-1");
    assert.equal(calls.length, 1);
    assert.equal(calls[0].truthLabel, "MEASURED_LOCAL");
    assert.equal(calls[0].consent, "APPEND CANONICAL RECEIPT");
    assert.equal(calls[0].canonicalBody.spine_hash, assembly.spine_hash);
  });

  it("refuses tampered assembly before any receipt write", async () => {
    const graph = fixture();
    const good = assembleSpineContext(graph, request);
    const forged = structuredClone(good);
    forged.context.target.title = "tampered";
    let calls = 0;
    const r = await sealSpineContextReceipt({
      graph,
      request,
      assembly: forged,
      demaHome: "/tmp/dema-test",
      now: new Date("2026-08-29T00:00:00Z"),
      appendReceipt: async () => {
        calls += 1;
        return { appended: true };
      },
      receiptConsentPhrase: "APPEND CANONICAL RECEIPT",
    });
    assert.equal(r.sealed, false);
    assert.equal(r.error, "spine_context_verification_failed");
    assert.equal(calls, 0);
  });
});
