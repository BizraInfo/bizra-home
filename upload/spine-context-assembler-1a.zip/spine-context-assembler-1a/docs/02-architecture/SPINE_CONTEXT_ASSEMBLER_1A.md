# SPINE-CONTEXT-ASSEMBLER-1A

## Purpose

Build the smallest deterministic context needed to work on one ultra-micro spec without dumping the repository into the model context window.

The admissible Spine is exactly:

```text
target micro-spec
+ architectural ancestors
+ public signatures of immediate dependencies
```

It is a read-only context compiler, not an execution engine and not a new authority.

## Files

- `packages/core/src/spine-context-assembler.js` — pure DAG traversal, projection, budget enforcement, deterministic hashing, re-derivation verifier.
- `packages/core/src/spine-context-fate-gate.js` — FATE authority adapter. L4 uses canonical exact-string `evaluateConsent`; no execution capability is minted.
- `packages/receipts/src/spine-context-receipt.js` — adapter into the existing canonical receipt chain. It re-derives the assembly before append and does not implement a new signing system.
- `tests/spine-context-assembler.test.js` — positive, negative, tamper, budget, FATE, and receipt-sealing controls.

## Graph contract

Supported relationship declarations:

```js
node.architectural_parents = ["parent-spec-id"];
node.dependencies = ["dependency-id"];
```

or explicit edges:

```js
{ from: "child", to: "parent", kind: "ARCHITECTURAL_PARENT" }
{ from: "consumer", to: "dependency", kind: "DEPENDS_ON" }
```

The graph must be acyclic. Dangling references and unknown edge kinds fail closed.

## Projection law

### Target

- `SPECIFY`: public contract only.
- `PLAN`, `TASKS`, `IMPLEMENT`: public contract + target implementation design when present.

### Architectural ancestors

Only the public architectural contract is admitted. Ancestor implementation bodies are never copied into the Spine.

### Immediate dependencies

Only `public_signature` is admitted. If a dependency has no explicit `public_signature`, the assembler may derive one only from public contract fields (`inputs`, `outputs`, `errors`, `invariants`, `schema`). Dependency implementation bodies never enter the Spine.

Transitive dependencies are intentionally excluded unless they are themselves architectural ancestors. A later micro-spec can widen this contract only with its own proof.

## Determinism

The assembly uses BIZRA Canonical JSON v1 and SHA-256. Node order in the source graph does not affect the resulting `spine_hash`.

The assembler refuses rather than truncates when `max_nodes` or `max_context_bytes` is exceeded.

The verifier re-runs the algorithm against the graph and request. A caller cannot promote a forged assembly by recomputing only an internal hash.

## FATE integration

This slice does not confuse context access with runtime authority.

```text
L0-L2  read-only local assembly permitted
L3     BLOCK: interactive human confirmation surface required
L4     canonical exact-string evaluateConsent()
L5     BLOCK
unknown BLOCK
```

Every FATE result pins:

```text
execution_authorized = false
capability_granted = false
authority_delta = 0
```

## Truth Spine sealing

`sealSpineContextReceipt()` first re-derives the assembly. Only then does it submit a narrow canonical body to Dema's existing `appendCanonicalReceipt()` rail.

Default Dema wiring reuses:

- `packages/receipts/src/canonical-ledger.js` → `appendCanonicalReceipt`
- `packages/receipts/src/canonical-receipt.js` → `CANONICAL_RECEIPT_CONSENT_PHRASE`

No new private-key handling or signing implementation is introduced.

The receipt proves only that the exact context assembly was re-derived and submitted to the canonical chain. It does not prove code correctness, runtime execution, model quality, production autonomy, human identity, federation, token, or economic action.

## Acceptance

Focused contract:

```bash
node --test tests/spine-context-assembler.test.js
```

Before admission into Dema, also run the repository-owned gates on the actual target branch:

```bash
npm test
npm run check
npm run llm:guidance
git diff --check
```

Do not call this production-active merely because the focused test is green. The production claim must remain bounded to a deterministic local context assembler plus its existing FATE/receipt adapters.
