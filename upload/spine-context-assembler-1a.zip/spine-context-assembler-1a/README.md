# Spine Context Assembler 1A — drop-in continuation bundle

This bundle contains the five remaining pieces requested for the in-progress Spine Context Assembler slice:

1. Core `SpineContextAssembler` algorithm.
2. FATE gate adapter.
3. Truth Spine / canonical-receipt adapter.
4. Focused tests.
5. Architecture README/index.

## Intended Dema paths

```text
packages/core/src/spine-context-assembler.js
packages/core/src/spine-context-fate-gate.js
packages/receipts/src/spine-context-receipt.js
tests/spine-context-assembler.test.js
docs/02-architecture/SPINE_CONTEXT_ASSEMBLER_1A.md
```

The bundle also includes copies of two already-existing Dema dependencies **only so the focused tests can run in isolation here**:

```text
packages/canon/src/sha256-canonical-json-v1.js
packages/fate/src/fate.js
```

Do not overwrite the repository copies without first re-deriving that they are byte-identical/current.

## Run focused tests

```bash
npm test
```

## Dema integration

The receipt adapter dynamically reuses the repository's existing canonical receipt chain by default. In Dema it expects:

```text
packages/receipts/src/canonical-ledger.js
packages/receipts/src/canonical-receipt.js
```

For focused tests the appender and canonical consent phrase are injected, so no test key generation or parallel ledger is required.

## Truth ceiling

This bundle is a continuation artifact, not proof that it has been applied to the live Dema checkout. Focused tests here prove the algorithm and adapter contracts in isolation. Repository admission still requires running Dema's own full gate ladder on the exact target branch/worktree.
