// SPINE-CONTEXT-RECEIPT-1A
// Canonical Truth-Spine adapter for a verified Spine context assembly.
// Reuses the existing canonical ledger and its existing signing rail.
// This module does NOT implement a new signer, key store, or receipt ledger.

import {
  SPINE_CONTEXT_ASSEMBLY_SCHEMA,
  verifySpineContextAssembly,
} from "../../core/src/spine-context-assembler.js";

export const SPINE_CONTEXT_RECEIPT_BODY_SCHEMA =
  "bizra.dema.spine_context_receipt_body.v0.1";
export const SPINE_CONTEXT_RECEIPT_TRUTH_LABEL = "MEASURED_LOCAL";

function freeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) freeze(child);
  return Object.freeze(value);
}

export function buildSpineContextReceiptBody({ assembly, fate = null } = {}) {
  if (!assembly || assembly.schema !== SPINE_CONTEXT_ASSEMBLY_SCHEMA || assembly.ok !== true) {
    throw new TypeError("verified spine context assembly required");
  }

  return freeze({
    schema: SPINE_CONTEXT_RECEIPT_BODY_SCHEMA,
    source_schema: assembly.schema,
    target_spec_id: assembly.target_spec_id,
    phase: assembly.phase,
    request_hash: assembly.request_hash,
    source_slice_hash: assembly.source_slice_hash,
    spine_hash: assembly.spine_hash,
    context_bytes: assembly.context_bytes,
    included_node_count: assembly.included_node_count,
    included_node_ids: assembly.included_node_ids,
    fate: fate
      ? {
          schema: fate.schema ?? null,
          autonomy_level: fate.autonomy_level ?? null,
          verdict: fate.verdict ?? null,
          permitted_for_context_assembly:
            fate.permitted_for_context_assembly === true,
          execution_authorized: false,
          capability_granted: false,
          authority_delta: 0,
        }
      : {
          schema: null,
          autonomy_level: null,
          verdict: "NOT_REQUIRED_FOR_READ_ONLY_ASSEMBLY",
          permitted_for_context_assembly: true,
          execution_authorized: false,
          capability_granted: false,
          authority_delta: 0,
        },
    what_this_proves:
      "a deterministic minimal Spine context was re-derived from the declared spec graph and request, and this exact assembly hash was submitted to the existing canonical receipt chain",
    what_this_does_not_prove:
      "it does not prove code correctness, runtime execution, model quality, production autonomy, human identity, capability authority, federation, token, or economic action",
    authority_delta: 0,
    boundary: {
      source_context_read_only: true,
      code_mutation: false,
      runtime_execution: false,
      model_invocation: false,
      network: false,
      federation: false,
      token: false,
      economy: false,
      authority_delta: 0,
    },
  });
}

async function loadCanonicalAppender() {
  const mod = await import("./canonical-ledger.js");
  if (typeof mod.appendCanonicalReceipt !== "function") {
    throw new Error("appendCanonicalReceipt_unavailable");
  }
  return mod.appendCanonicalReceipt;
}

async function loadCanonicalConsentPhrase() {
  const mod = await import("./canonical-receipt.js");
  if (typeof mod.CANONICAL_RECEIPT_CONSENT_PHRASE !== "string") {
    throw new Error("canonical_receipt_consent_phrase_unavailable");
  }
  return mod.CANONICAL_RECEIPT_CONSENT_PHRASE;
}

/**
 * Re-derive the assembly before sealing it. No caller-supplied "verified: true"
 * flag can bypass the graph/request comparison.
 *
 * appendReceipt and receiptConsentPhrase are injectable for focused tests. In
 * Dema production wiring, omit them to reuse canonical-ledger.js and
 * CANONICAL_RECEIPT_CONSENT_PHRASE.
 */
export async function sealSpineContextReceipt({
  graph,
  request,
  assembly,
  fate = null,
  demaHome,
  now,
  appendReceipt,
  receiptConsentPhrase,
} = {}) {
  const verification = verifySpineContextAssembly({ graph, request, assembly });
  if (!verification.ok) {
    return freeze({
      sealed: false,
      error: "spine_context_verification_failed",
      verification,
      authority_delta: 0,
    });
  }
  if (fate && fate.permitted_for_context_assembly !== true) {
    return freeze({
      sealed: false,
      error: "fate_context_assembly_not_permitted",
      verification,
      authority_delta: 0,
    });
  }
  if (now === undefined || now === null) {
    return freeze({
      sealed: false,
      error: "now_required",
      verification,
      authority_delta: 0,
    });
  }

  const append = appendReceipt ?? (await loadCanonicalAppender());
  const consent =
    receiptConsentPhrase ?? (await loadCanonicalConsentPhrase());
  const canonicalBody = buildSpineContextReceiptBody({ assembly, fate });

  const result = await append({
    canonicalBody,
    truthLabel: SPINE_CONTEXT_RECEIPT_TRUTH_LABEL,
    whatProves: canonicalBody.what_this_proves,
    whatDoesNotProve: canonicalBody.what_this_does_not_prove,
    consent,
    demaHome,
    now,
  });

  if (!result?.appended) {
    return freeze({
      sealed: false,
      error: result?.reason ?? result?.error ?? "canonical_receipt_append_failed",
      verification,
      canonical_body: canonicalBody,
      authority_delta: 0,
    });
  }

  return freeze({
    sealed: true,
    schema: "bizra.dema.spine_context_receipt_seal.v0.1",
    receipt_id: result.receipt?.receipt_id ?? null,
    head: result.head ?? null,
    length: result.length ?? null,
    spine_hash: assembly.spine_hash,
    verification,
    authority_delta: 0,
  });
}
