export function evaluateConsent({ phrase, requiredPhrase }) {
  const accepted = phrase === requiredPhrase;
  return {
    accepted,
    truthLabel: "MEASURED",
    reason: accepted ? "Exact consent phrase matched." : "Exact consent phrase not provided."
  };
}
