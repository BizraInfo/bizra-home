// CANONICAL-JSON-V1-0A — sha256 binding over canonical v1 bytes.
//
// Schema:      bizra.canonical-json.v1
// Truth Label: LOCALLY_IMPLEMENTED
//
// Canonical form rules:
//   1. Object keys sorted by Unicode codepoint (UTF-8 byte order, NOT
//      UTF-16 code-unit order — JavaScript's default Array.sort is wrong
//      for supplementary-plane characters and must not be used).
//   2. UTF-8 encoded.
//   3. No whitespace between tokens.
//   4. Arrays preserve order (do NOT sort array elements).
//   5. Undefined, function, symbol values are rejected.
//   6. NaN, Infinity, -Infinity are rejected (not valid JSON).
//   7. Numbers serialize via JSON.stringify (Node 20+ behavior pinned by
//      the conformance suite).
//   8. Booleans serialize as lowercase `true` / `false`.
//   9. Null serializes as `null`.
//
// This is the pure kernel. No I/O. No external dependencies beyond
// node:crypto. Fail-closed: any non-serializable input throws.

import crypto from 'node:crypto';

export const CANONICAL_JSON_V1_SCHEMA = 'bizra.canonical-json.v1';
export const CANONICAL_JSON_V1_TRUTH_LABEL = 'LOCALLY_IMPLEMENTED';

/**
 * Compare two strings by Unicode codepoint.
 *
 * UTF-8 byte order matches codepoint order (a property of UTF-8 itself),
 * so we compare the UTF-8 byte sequences lexicographically. This is
 * correct for all of Unicode, including supplementary-plane characters
 * (emoji, rare CJK) that JavaScript's default UTF-16 code-unit sort
 * would misorder.
 *
 * Example: the strings "\u{1F600}" (😀) and "\uFFFF" would sort in
 * the WRONG order under default Array.sort (UTF-16), because the
 * emoji's surrogate pair (0xD83D 0xDE00) starts with a high surrogate
 * (0xD83D) which is less than 0xFFFF. Under codepoint sort, the emoji
 * is U+1F600 (greater than U+FFFF) and sorts after.
 */
export function codepointCompare(a, b) {
  const ba = Buffer.from(String(a), 'utf8');
  const bb = Buffer.from(String(b), 'utf8');
  return ba.compare(bb);
}

/**
 * Canonicalize a JSON-serializable value.
 * Returns a string in canonical form.
 * Throws TypeError on non-serializable values.
 */
export function canonicalizeV1(value) {
  if (value === null) return 'null';

  const t = typeof value;

  if (t === 'string') return JSON.stringify(value);
  if (t === 'boolean') return value ? 'true' : 'false';

  if (t === 'number') {
    if (!Number.isFinite(value)) {
      throw new TypeError(`Canonical JSON v1 rejects non-finite numbers: ${value}`);
    }
    // JSON.stringify produces canonical number form for finite numbers
    // in Node.js. The conformance suite pins this for cross-runtime
    // reproducibility.
    return JSON.stringify(value);
  }

  if (t === 'undefined' || t === 'function' || t === 'symbol') {
    throw new TypeError(`Canonical JSON v1 rejects ${t} values`);
  }

  if (t === 'bigint') {
    throw new TypeError('Canonical JSON v1 rejects bigint values (use number)');
  }

  if (t !== 'object') {
    throw new TypeError(`Canonical JSON v1 rejects ${t} values`);
  }

  if (Array.isArray(value)) {
    const parts = [];
    for (const v of value) {
      if (typeof v === 'undefined') {
        // JSON.stringify converts undefined in arrays to null
        parts.push('null');
      } else {
        parts.push(canonicalizeV1(v));
      }
    }
    return '[' + parts.join(',') + ']';
  }

  // Object — sort keys by codepoint
  const keys = Object.keys(value).sort(codepointCompare);
  const parts = [];
  for (const k of keys) {
    const v = value[k];
    // Skip undefined values (matches JSON.stringify behavior for objects)
    if (typeof v === 'undefined') continue;
    parts.push(JSON.stringify(k) + ':' + canonicalizeV1(v));
  }
  return '{' + parts.join(',') + '}';
}

/**
 * Compute SHA-256 over the canonical UTF-8 byte representation.
 * Returns hex-encoded digest (64 lowercase hex chars).
 *
 * @param {Object} payload - non-null object to hash
 * @returns {string} sha256 hex digest
 * @throws {TypeError} if payload is not a non-null object
 * @throws {TypeError} if payload contains non-serializable values
 */
export function sha256CanonicalJsonV1(payload) {
  if (payload === null || typeof payload !== 'object') {
    throw new TypeError('Payload for canonical hashing must be a non-null object.');
  }
  if (Array.isArray(payload)) {
    throw new TypeError('Payload for canonical hashing must be an object, not an array.');
  }
  const canonical = canonicalizeV1(payload);
  return crypto.createHash('sha256').update(canonical, 'utf8').digest('hex');
}

/**
 * Returns the canonical string form (for debugging and cross-repo
 * comparison). The Data Lake implementation must produce a byte-identical
 * string for the same input.
 *
 * @param {Object} payload
 * @returns {string}
 */
export function canonicalJsonV1String(payload) {
  if (payload === null || typeof payload !== 'object') {
    throw new TypeError('Payload for canonicalization must be a non-null object.');
  }
  return canonicalizeV1(payload);
}
