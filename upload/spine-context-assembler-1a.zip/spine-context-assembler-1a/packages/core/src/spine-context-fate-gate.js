// SPINE-CONTEXT-FATE-GATE-1A
// Authority adapter for context assembly. It grants no execution authority.
// L0-L2: safe local read-only context assembly.
// L3: requires a human prompt surface (this pure adapter cannot prompt).
// L4: exact-string consent through the canonical FATE evaluateConsent().
// L5: unconditional refusal.

import { evaluateConsent } from "../../fate/src/fate.js";
import { assembleSpineContext } from "./spine-context-assembler.js";

export const SPINE_CONTEXT_FATE_SCHEMA =
  "bizra.dema.spine_context_fate_gate.v0.1";

const SAFE_LEVELS = new Set(["L0", "L1", "L2"]);

function freeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) freeze(child);
  return Object.freeze(value);
}

export function evaluateSpineContextAuthority({
  autonomy_level = "L0",
  phrase,
  required_phrase,
} = {}) {
  const level = String(autonomy_level || "").toUpperCase();
  const base = {
    schema: SPINE_CONTEXT_FATE_SCHEMA,
    autonomy_level: level,
    execution_authorized: false,
    capability_granted: false,
    authority_delta: 0,
  };

  if (SAFE_LEVELS.has(level)) {
    return freeze({
      ...base,
      permitted_for_context_assembly: true,
      verdict: "PERMIT_CONTEXT_ASSEMBLY_ONLY",
      fate_invoked: false,
      reason: "Local read-only context assembly is below the human-consent threshold.",
    });
  }

  if (level === "L3") {
    return freeze({
      ...base,
      permitted_for_context_assembly: false,
      verdict: "BLOCK_HUMAN_CONFIRMATION_REQUIRED",
      fate_invoked: false,
      reason: "L3 requires an interactive human approval surface; this adapter fails closed.",
    });
  }

  if (level === "L4") {
    if (typeof required_phrase !== "string" || required_phrase.length === 0) {
      return freeze({
        ...base,
        permitted_for_context_assembly: false,
        verdict: "BLOCK_REQUIRED_PHRASE_MISSING",
        fate_invoked: true,
        reason: "L4 requires an explicit exact consent phrase contract.",
      });
    }
    const result = evaluateConsent({ phrase, requiredPhrase: required_phrase });
    return freeze({
      ...base,
      permitted_for_context_assembly: result.accepted === true,
      verdict:
        result.accepted === true
          ? "PERMIT_CONTEXT_ASSEMBLY_ONLY"
          : "BLOCK_EXACT_CONSENT_MISMATCH",
      fate_invoked: true,
      fate_truth_label: result.truthLabel ?? null,
      reason: result.reason ?? null,
    });
  }

  if (level === "L5") {
    return freeze({
      ...base,
      permitted_for_context_assembly: false,
      verdict: "BLOCK_L5_FORBIDDEN",
      fate_invoked: false,
      reason: "L5 operations are forbidden by this adapter.",
    });
  }

  return freeze({
    ...base,
    permitted_for_context_assembly: false,
    verdict: "BLOCK_UNKNOWN_AUTONOMY_LEVEL",
    fate_invoked: false,
    reason: "Unknown autonomy levels fail closed.",
  });
}

export function assembleSpineContextWithFate({
  graph,
  request,
  autonomy_level = "L0",
  phrase,
  required_phrase,
} = {}) {
  const fate = evaluateSpineContextAuthority({
    autonomy_level,
    phrase,
    required_phrase,
  });
  if (!fate.permitted_for_context_assembly) {
    return freeze({
      ok: false,
      schema: "bizra.dema.spine_context_fate_assembly.v0.1",
      fate,
      assembly: null,
      blocked_by: [fate.verdict],
      authority_delta: 0,
    });
  }

  const assembly = assembleSpineContext(graph, request);
  return freeze({
    ok: assembly.ok,
    schema: "bizra.dema.spine_context_fate_assembly.v0.1",
    fate,
    assembly,
    blocked_by: assembly.blocked_by,
    authority_delta: 0,
  });
}
