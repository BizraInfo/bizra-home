// SPINE-CONTEXT-ASSEMBLER-1A
// Pure, read-only context minimizer for ultra-micro specification DAGs.
//
// Contract:
//   target micro-spec
//   + architectural ancestors
//   + PUBLIC signatures of IMMEDIATE dependencies
//   = deterministic minimal Spine context.
//
// No fs, network, model, process, clock, random, signing, mutation, or authority.

import {
  canonicalJsonV1String,
  sha256CanonicalJsonV1,
} from "../../canon/src/sha256-canonical-json-v1.js";

export const SPINE_CONTEXT_ASSEMBLY_SCHEMA =
  "bizra.dema.spine_context_assembly.v0.1";
export const SPINE_CONTEXT_ASSEMBLY_TRUTH_LABEL =
  "SPINE_CONTEXT_ASSEMBLY_LOCAL_ONLY";
export const SPINE_CONTEXT_GRAPH_SCHEMA =
  "bizra.dema.ultra_micro_spec_graph.v0.1";

export const SPINE_CONTEXT_PHASES = Object.freeze([
  "SPECIFY",
  "PLAN",
  "TASKS",
  "IMPLEMENT",
]);

export const SPINE_EDGE_KINDS = Object.freeze({
  ARCHITECTURAL_PARENT: "ARCHITECTURAL_PARENT",
  DEPENDS_ON: "DEPENDS_ON",
});

export const DEFAULT_SPINE_LIMITS = Object.freeze({
  maxNodes: 64,
  maxContextBytes: 128 * 1024,
});

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function nonEmptyString(value) {
  return typeof value === "string" && value.trim().length > 0;
}

function sortedUnique(values) {
  return [...new Set(values)].sort((a, b) => String(a).localeCompare(String(b)));
}

function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}

function reject(blocked_by, extra = {}) {
  return deepFreeze({
    ok: false,
    schema: SPINE_CONTEXT_ASSEMBLY_SCHEMA,
    truth_label: SPINE_CONTEXT_ASSEMBLY_TRUTH_LABEL,
    blocked_by: sortedUnique(blocked_by),
    authority_delta: 0,
    boundary: boundary(),
    ...extra,
  });
}

function boundary() {
  return {
    filesystem_write: false,
    repository_mutation: false,
    network: false,
    model_invocation: false,
    runtime_execution: false,
    signing: false,
    token: false,
    economy: false,
    federation: false,
    authority_delta: 0,
  };
}

function normalizeRequest(request = {}) {
  const phase = String(request.phase || "IMPLEMENT").toUpperCase();
  return {
    target_spec_id: request.target_spec_id,
    phase,
    max_nodes: request.max_nodes ?? DEFAULT_SPINE_LIMITS.maxNodes,
    max_context_bytes:
      request.max_context_bytes ?? DEFAULT_SPINE_LIMITS.maxContextBytes,
  };
}

function relationMaps(graph, nodeIndex) {
  const parents = new Map();
  const dependencies = new Map();
  for (const id of nodeIndex.keys()) {
    parents.set(id, new Set());
    dependencies.set(id, new Set());
  }

  const add = (map, from, to, code) => {
    if (!nodeIndex.has(from) || !nodeIndex.has(to)) {
      throw new Error(`${code}:${from}->${to}`);
    }
    map.get(from).add(to);
  };

  for (const node of nodeIndex.values()) {
    for (const parent of node.architectural_parents || []) {
      add(parents, node.id, parent, "dangling_architectural_parent");
    }
    for (const dep of node.dependencies || []) {
      add(dependencies, node.id, dep, "dangling_dependency");
    }
  }

  for (const edge of graph.edges || []) {
    if (!isObject(edge) || !nonEmptyString(edge.from) || !nonEmptyString(edge.to)) {
      throw new Error("edge_invalid");
    }
    const kind = String(edge.kind || "").toUpperCase();
    if (kind === SPINE_EDGE_KINDS.ARCHITECTURAL_PARENT) {
      add(parents, edge.from, edge.to, "dangling_architectural_parent");
    } else if (kind === SPINE_EDGE_KINDS.DEPENDS_ON) {
      add(dependencies, edge.from, edge.to, "dangling_dependency");
    } else {
      throw new Error(`edge_kind_unknown:${edge.kind ?? ""}`);
    }
  }

  return { parents, dependencies };
}

function assertAcyclic(nodeIndex, relations) {
  const state = new Map();
  const stack = [];

  const nextIds = (id) => sortedUnique([
    ...(relations.parents.get(id) || []),
    ...(relations.dependencies.get(id) || []),
  ]);

  function visit(id) {
    const s = state.get(id) || 0;
    if (s === 2) return;
    if (s === 1) {
      const start = stack.indexOf(id);
      const cycle = [...stack.slice(start), id].join("->");
      throw new Error(`graph_cycle:${cycle}`);
    }
    state.set(id, 1);
    stack.push(id);
    for (const next of nextIds(id)) visit(next);
    stack.pop();
    state.set(id, 2);
  }

  for (const id of sortedUnique([...nodeIndex.keys()])) visit(id);
}

function collectAncestors(targetId, parents) {
  const emitted = new Set();
  const ordered = [];

  function visit(id) {
    for (const parent of sortedUnique([...(parents.get(id) || [])])) {
      visit(parent);
      if (!emitted.has(parent)) {
        emitted.add(parent);
        ordered.push(parent);
      }
    }
  }

  visit(targetId);
  return ordered;
}

function publicContract(node) {
  if (isObject(node.public_contract)) return node.public_contract;
  if (isObject(node.contract?.public)) return node.contract.public;
  return null;
}

function implementationDesign(node) {
  if (isObject(node.implementation_design)) return node.implementation_design;
  if (isObject(node.contract?.implementation)) return node.contract.implementation;
  return null;
}

function publicSignature(node) {
  if (isObject(node.public_signature)) return node.public_signature;
  const pc = publicContract(node);
  if (isObject(pc?.signature)) return pc.signature;
  if (isObject(pc)) {
    const signature = {};
    for (const key of ["inputs", "outputs", "errors", "invariants", "schema"]) {
      if (pc[key] !== undefined) signature[key] = pc[key];
    }
    return Object.keys(signature).length > 0 ? signature : null;
  }
  return null;
}

function baseProjection(node) {
  return {
    id: node.id,
    kind: node.kind ?? "SPEC",
    title: node.title ?? null,
    source_ref: node.source_ref ?? null,
    truth_label: node.truth_label ?? null,
  };
}

function projectTarget(node, phase) {
  const out = {
    ...baseProjection(node),
    public_contract: publicContract(node),
  };
  if (phase !== "SPECIFY") {
    const design = implementationDesign(node);
    if (design) out.implementation_design = design;
  }
  return out;
}

function projectAncestor(node) {
  return {
    ...baseProjection(node),
    public_contract: publicContract(node),
  };
}

function projectDependency(node) {
  return {
    ...baseProjection(node),
    public_signature: publicSignature(node),
  };
}

function selectedSourceSlice({ nodeIndex, relations, selectedIds }) {
  const ids = new Set(selectedIds);
  const nodes = sortedUnique(selectedIds).map((id) => nodeIndex.get(id));
  const edges = [];

  for (const from of sortedUnique(selectedIds)) {
    for (const to of sortedUnique([...(relations.parents.get(from) || [])])) {
      if (ids.has(to)) edges.push({ from, to, kind: SPINE_EDGE_KINDS.ARCHITECTURAL_PARENT });
    }
    for (const to of sortedUnique([...(relations.dependencies.get(from) || [])])) {
      if (ids.has(to)) edges.push({ from, to, kind: SPINE_EDGE_KINDS.DEPENDS_ON });
    }
  }
  edges.sort((a, b) =>
    `${a.from}\u0000${a.kind}\u0000${a.to}`.localeCompare(`${b.from}\u0000${b.kind}\u0000${b.to}`),
  );
  return { nodes, edges };
}

/**
 * Build the minimal deterministic Spine context for one target micro-spec.
 *
 * Edge direction:
 *   child --ARCHITECTURAL_PARENT--> parent
 *   consumer --DEPENDS_ON--> dependency
 */
export function assembleSpineContext(graph, request = {}) {
  const blocked = [];
  if (!isObject(graph)) return reject(["graph_required"]);
  if (!Array.isArray(graph.nodes) || graph.nodes.length === 0) {
    return reject(["graph_nodes_required"]);
  }

  const req = normalizeRequest(request);
  if (!nonEmptyString(req.target_spec_id)) blocked.push("target_spec_id_required");
  if (!SPINE_CONTEXT_PHASES.includes(req.phase)) blocked.push("phase_invalid");
  if (!Number.isInteger(req.max_nodes) || req.max_nodes < 1) blocked.push("max_nodes_invalid");
  if (!Number.isInteger(req.max_context_bytes) || req.max_context_bytes < 1) {
    blocked.push("max_context_bytes_invalid");
  }
  if (blocked.length) return reject(blocked, { request: req });

  const nodeIndex = new Map();
  for (const node of graph.nodes) {
    if (!isObject(node) || !nonEmptyString(node.id)) {
      blocked.push("node_id_invalid");
      continue;
    }
    if (nodeIndex.has(node.id)) blocked.push(`duplicate_node:${node.id}`);
    nodeIndex.set(node.id, node);
  }
  if (blocked.length) return reject(blocked, { request: req });
  if (!nodeIndex.has(req.target_spec_id)) {
    return reject([`target_not_found:${req.target_spec_id}`], { request: req });
  }

  let relations;
  try {
    relations = relationMaps(graph, nodeIndex);
    assertAcyclic(nodeIndex, relations);
  } catch (error) {
    return reject([error?.message || "graph_invalid"], { request: req });
  }

  const target = nodeIndex.get(req.target_spec_id);
  if (!publicContract(target)) blocked.push(`target_public_contract_missing:${target.id}`);

  const ancestorIds = collectAncestors(req.target_spec_id, relations.parents);
  for (const id of ancestorIds) {
    if (!publicContract(nodeIndex.get(id))) blocked.push(`ancestor_public_contract_missing:${id}`);
  }

  const dependencyIds = sortedUnique([...(relations.dependencies.get(req.target_spec_id) || [])]);
  for (const id of dependencyIds) {
    if (!publicSignature(nodeIndex.get(id))) blocked.push(`dependency_public_signature_missing:${id}`);
  }

  if (blocked.length) return reject(blocked, { request: req });

  const includedNodeIds = sortedUnique([
    req.target_spec_id,
    ...ancestorIds,
    ...dependencyIds,
  ]);
  if (includedNodeIds.length > req.max_nodes) {
    return reject([
      `node_budget_exceeded:${includedNodeIds.length}>${req.max_nodes}`,
    ], { request: req });
  }

  const context = {
    target: projectTarget(target, req.phase),
    architectural_ancestors: ancestorIds.map((id) => projectAncestor(nodeIndex.get(id))),
    immediate_dependencies: dependencyIds.map((id) => projectDependency(nodeIndex.get(id))),
  };

  const canonicalContext = canonicalJsonV1String(context);
  const contextBytes = Buffer.byteLength(canonicalContext, "utf8");
  if (contextBytes > req.max_context_bytes) {
    return reject([
      `context_budget_exceeded:${contextBytes}>${req.max_context_bytes}`,
    ], { request: req });
  }

  const requestHash = sha256CanonicalJsonV1(req);
  const sourceSliceHash = sha256CanonicalJsonV1(
    selectedSourceSlice({ nodeIndex, relations, selectedIds: includedNodeIds }),
  );

  const body = {
    schema: SPINE_CONTEXT_ASSEMBLY_SCHEMA,
    truth_label: SPINE_CONTEXT_ASSEMBLY_TRUTH_LABEL,
    graph_schema: graph.schema ?? null,
    target_spec_id: req.target_spec_id,
    phase: req.phase,
    request_hash: requestHash,
    source_slice_hash: sourceSliceHash,
    context_bytes: contextBytes,
    included_node_count: includedNodeIds.length,
    included_node_ids: includedNodeIds,
    excluded_node_count: Math.max(0, nodeIndex.size - includedNodeIds.length),
    context,
    authority_delta: 0,
    boundary: boundary(),
  };

  const spineHash = sha256CanonicalJsonV1(body);
  return deepFreeze({
    ok: true,
    ...body,
    spine_hash: spineHash,
    blocked_by: Object.freeze([]),
  });
}

export function verifySpineContextAssembly({ graph, request, assembly } = {}) {
  if (!isObject(assembly)) {
    return deepFreeze({ ok: false, blocked_by: ["assembly_required"] });
  }
  const rebuilt = assembleSpineContext(graph, request);
  if (!rebuilt.ok) {
    return deepFreeze({
      ok: false,
      blocked_by: rebuilt.blocked_by.map((x) => `rebuild:${x}`),
      rebuilt,
    });
  }

  let actual;
  let expected;
  try {
    actual = canonicalJsonV1String(assembly);
    expected = canonicalJsonV1String(rebuilt);
  } catch (error) {
    return deepFreeze({
      ok: false,
      blocked_by: [`assembly_not_canonicalizable:${error?.message || String(error)}`],
    });
  }

  const blocked_by = [];
  if (assembly.spine_hash !== rebuilt.spine_hash) blocked_by.push("spine_hash_mismatch");
  if (actual !== expected) blocked_by.push("assembly_semantic_mismatch");
  if (assembly.authority_delta !== 0) blocked_by.push("authority_delta_nonzero");

  return deepFreeze({
    ok: blocked_by.length === 0,
    schema: "bizra.dema.spine_context_assembly_verification.v0.1",
    spine_hash: rebuilt.spine_hash,
    blocked_by: sortedUnique(blocked_by),
    authority_delta: 0,
  });
}

export class SpineContextAssembler {
  constructor({ maxNodes, maxContextBytes } = {}) {
    this.maxNodes = maxNodes ?? DEFAULT_SPINE_LIMITS.maxNodes;
    this.maxContextBytes = maxContextBytes ?? DEFAULT_SPINE_LIMITS.maxContextBytes;
    Object.freeze(this);
  }

  assemble(graph, request = {}) {
    return assembleSpineContext(graph, {
      ...request,
      max_nodes: request.max_nodes ?? this.maxNodes,
      max_context_bytes: request.max_context_bytes ?? this.maxContextBytes,
    });
  }

  verify(graph, request, assembly) {
    return verifySpineContextAssembly({
      graph,
      request: {
        ...request,
        max_nodes: request?.max_nodes ?? this.maxNodes,
        max_context_bytes: request?.max_context_bytes ?? this.maxContextBytes,
      },
      assembly,
    });
  }
}
