/* BIZRA ecosystem walkthrough — continuous composition on animations-v3 engine.
   One world (1920 x 5400), camera travels down the constitutional stack and back. */
(function () {
  const { React, CompositionStage, useComposition, Captions, Easing, clamp } = window;
  const h = React.createElement;

  // ---------- palette / type ----------
  const INK = '#050B14', PARCH = '#F8F6F1', GOLD = '#C9A962', GREEN = '#34D399', RED = '#F87171';
  const DIM = 'rgba(248,246,241,.55)', FAINT = 'rgba(248,246,241,.28)';
  const LINE = 'rgba(248,246,241,.16)', CARD = 'rgba(248,246,241,.045)';
  const SERIF = "'Playfair Display', Georgia, serif";
  const SANS = "'Inter', system-ui, sans-serif";
  const MONO = "'IBM Plex Mono', monospace";

  // ---------- exactly three motion helpers ----------
  const MOTION = {
    enter: (T, at, d = 0.9, dy = 26) => {
      const e = Easing.easeOutCubic(clamp((T - at) / d, 0, 1));
      return { opacity: e, transform: `translateY(${(1 - e) * dy}px)` };
    },
    pop: (T, at, d = 0.7) => {
      const p = clamp((T - at) / d, 0, 1);
      return { opacity: Math.min(1, p * 2.5), transform: `scale(${0.62 + 0.38 * Easing.easeOutBack(p)})` };
    },
    draw: (T, at, d = 1) => Easing.easeInOutCubic(clamp((T - at) / d, 0, 1)),
  };

  // ---------- camera ----------
  function camAt(T, keys) {
    if (T <= keys[0][0]) { const k = keys[0]; return { x: k[1], y: k[2], s: k[3] }; }
    for (let i = 0; i < keys.length - 1; i++) {
      const a = keys[i], b = keys[i + 1];
      if (T >= a[0] && T <= b[0]) {
        const p = Easing.easeInOutSine((T - a[0]) / Math.max(0.001, b[0] - a[0]));
        return { x: a[1] + (b[1] - a[1]) * p, y: a[2] + (b[2] - a[2]) * p, s: a[3] + (b[3] - a[3]) * p };
      }
    }
    const k = keys[keys.length - 1]; return { x: k[1], y: k[2], s: k[3] };
  }

  // ---------- small building blocks ----------
  const label = (txt, extra) => h('div', { style: Object.assign({ fontFamily: MONO, fontSize: 15, letterSpacing: '.22em', color: GOLD, textTransform: 'uppercase' }, extra) }, txt);

  function Tile({ x, y, w, hgt, title, lines, st, accent, titleSize }) {
    return h('div', { style: Object.assign({ position: 'absolute', left: x, top: y, width: w, height: hgt, border: `1px solid ${LINE}`, borderRadius: 10, background: CARD, padding: '14px 16px', boxSizing: 'border-box' }, st) },
      h('div', { style: { fontFamily: SANS, fontWeight: 600, fontSize: titleSize || 21, color: accent || PARCH, marginBottom: lines ? 6 : 0, lineHeight: 1.15 } }, title),
      lines ? h('div', { style: { fontFamily: SANS, fontSize: 15.5, color: DIM, lineHeight: 1.45 } }, lines) : null);
  }

  function ZoneTitle({ y, txt, sub }) {
    return h('div', { style: { position: 'absolute', left: 0, width: 1920, top: y, textAlign: 'center', pointerEvents: 'none' } },
      h('div', { style: { fontFamily: SERIF, fontSize: 130, color: 'rgba(248,246,241,.07)', letterSpacing: '.06em', whiteSpace: 'nowrap' } }, txt),
      sub ? h('div', { style: { fontFamily: MONO, fontSize: 22, letterSpacing: '.3em', color: 'rgba(201,169,98,.35)', marginTop: -18, textTransform: 'uppercase' } }, sub) : null);
  }

  const Arrow = ({ x, y, hgt, T, at, color }) => h('div', { style: { position: 'absolute', left: x - 1, top: y, width: 2, height: hgt * MOTION.draw(T, at, 0.8), background: color || 'rgba(201,169,98,.5)' } });

  // ================================================================ sections
  function Personal({ T, C }) {
    const els = [];
    // human
    els.push(h('div', { key: 'hu', style: Object.assign({ position: 'absolute', left: 760, top: 176, width: 400, textAlign: 'center' }, MOTION.pop(T, C.Human + 0.3)) },
      h('div', { style: { width: 54, height: 54, borderRadius: '50%', border: `2.5px solid ${PARCH}`, margin: '0 auto' } }),
      h('div', { style: { width: 108, height: 50, borderRadius: '54px 54px 0 0', border: `2.5px solid ${PARCH}`, borderBottom: 'none', margin: '8px auto 0' } }),
      h('div', { style: { fontFamily: SERIF, fontSize: 40, color: PARCH, marginTop: 12, whiteSpace: 'nowrap' } }, 'The Human Sovereign'),
      h('div', { style: { fontFamily: MONO, fontSize: 14, letterSpacing: '.18em', color: GOLD, marginTop: 4, whiteSpace: 'nowrap' } }, 'ONE HUMAN \u00B7 ONE NODE')));
    // dema ring
    const dr = MOTION.draw(T, C.Dema + 0.2, 1.4);
    els.push(h('div', { key: 'dm', style: { position: 'absolute', left: 960 - 210, top: 462, width: 420, height: 150, opacity: Math.min(1, dr * 2) } },
      h('div', { style: { position: 'absolute', inset: 0, borderRadius: 90, border: `2px solid rgba(201,169,98,${0.75 * dr})`, boxShadow: `0 0 ${40 * dr}px rgba(201,169,98,.18)` } }),
      h('div', { style: { position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4 } },
        h('div', { style: { fontFamily: SERIF, fontSize: 46, color: GOLD } }, 'Dema'),
        h('div', { style: { fontFamily: SANS, fontSize: 16, color: DIM } }, 'companion membrane \u2014 the door'))));
    els.push(h('div', { key: 'dm2', style: Object.assign({ position: 'absolute', left: 660, top: 628, width: 600, textAlign: 'center', fontFamily: SANS, fontSize: 16, color: DIM }, MOTION.enter(T, C.Dema + 1.6)) },
      'listens \u00B7 remembers context \u00B7 explains plainly \u00B7 asks exact consent'));
    // PAT row
    const pats = [['PAT-1', 'Mission Scribe'], ['PAT-2', 'Research Companion'], ['PAT-3', 'Code Apprentice'], ['PAT-4', 'Memory Curator'], ['PAT-5', 'Consent Drafter'], ['PAT-6', 'Receipt Recorder'], ['PAT-7', 'Reflection Witness']];
    els.push(h('div', { key: 'ptt', style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 668, textAlign: 'center' }, MOTION.enter(T, C.PAT + 0.2)) },
      h('div', { style: { fontFamily: SERIF, fontSize: 38, color: PARCH } }, 'PAT \u00D7 7 \u2014 your Personal Agentic Team')));
    els.push(h('div', { key: 'pt', style: { position: 'absolute', left: 160, top: 726, width: 1600, display: 'flex', gap: 14 } },
      pats.map((p, i) => h('div', { key: p[0], style: Object.assign({ flex: 1, border: `1px solid ${LINE}`, borderRadius: 10, background: CARD, padding: '14px 10px', textAlign: 'center' }, MOTION.pop(T, C.PAT + 0.7 + i * 0.42)) },
        h('div', { style: { fontFamily: MONO, fontSize: 13, color: GOLD, letterSpacing: '.14em' } }, p[0]),
        h('div', { style: { fontFamily: SANS, fontSize: 16.5, fontWeight: 600, color: PARCH, marginTop: 6, lineHeight: 1.25 } }, p[1])))));
    els.push(h('div', { key: 'pv', style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 842, textAlign: 'center' }, MOTION.enter(T, C.PAT + 4.6)) },
      h('span', { style: { fontFamily: MONO, fontSize: 15, letterSpacing: '.2em', color: GREEN, border: `1px solid rgba(91,174,127,.5)`, borderRadius: 20, padding: '7px 18px' } }, 'PRIVATE \u2014 STAYS ON YOUR MACHINE')));
    // proposal card
    const rows = [['mission', 'organize & summarize my research folder'], ['risk class', 'LOW \u2014 read + write inside one folder'], ['cost', '\u2248 4 min local compute \u00B7 0 external calls'], ['preview', 'reversible \u2014 full undo plan attached']];
    els.push(h('div', { key: 'pr', style: Object.assign({ position: 'absolute', left: 660, top: 902, width: 600, border: `1px solid rgba(201,169,98,.55)`, borderRadius: 12, background: 'rgba(201,169,98,.06)', padding: '18px 24px' }, MOTION.pop(T, C.Proposal + 0.3)) },
      label('Mission proposal', { marginBottom: 10 }),
      rows.map((r, i) => h('div', { key: i, style: Object.assign({ display: 'flex', gap: 14, padding: '5px 0', borderTop: i ? `1px solid rgba(248,246,241,.08)` : 'none' }, MOTION.enter(T, C.Proposal + 0.8 + i * 0.5, 0.6, 10)) },
        h('div', { style: { fontFamily: MONO, fontSize: 14, color: FAINT, width: 120, flex: 'none' } }, r[0]),
        h('div', { style: { fontFamily: SANS, fontSize: 16, color: PARCH } }, r[1])))));
    return h('div', null, els);
  }

  function Fate({ T, C }) {
    const checks = ['identity', 'exact consent', 'scope', 'expiry', 'budget', 'reversibility'];
    const on = MOTION.draw(T, C.FATE + 0.2, 1);
    return h('div', null,
      h('div', { style: { position: 'absolute', left: 120, top: 1058, width: 1680, height: 176, border: `2px solid rgba(201,169,98,${0.35 + 0.5 * on})`, borderRadius: 14, background: 'rgba(201,169,98,.05)', boxShadow: `0 0 ${50 * on}px rgba(201,169,98,.12)` } },
        h('div', { style: { display: 'flex', alignItems: 'baseline', gap: 20, padding: '16px 28px 4px' } },
          h('div', { style: { fontFamily: SERIF, fontSize: 44, color: GOLD } }, 'FATE'),
          h('div', { style: { fontFamily: SANS, fontSize: 17, color: DIM } }, 'the sovereign consent gate \u2014 nothing crosses without you'),
          h('div', { style: { marginLeft: 'auto', fontFamily: MONO, fontSize: 14, letterSpacing: '.2em', color: RED } }, 'FAIL-CLOSED')),
        h('div', { style: { display: 'flex', gap: 12, padding: '10px 28px' } },
          checks.map((c, i) => {
            const lit = T > C.FATE + 1 + i * 0.55;
            return h('div', { key: c, style: { flex: 1, border: `1px solid ${lit ? 'rgba(91,174,127,.6)' : LINE}`, borderRadius: 8, padding: '9px 8px', textAlign: 'center', fontFamily: SANS, fontSize: 15.5, color: lit ? GREEN : FAINT, background: lit ? 'rgba(91,174,127,.07)' : 'transparent', transition: 'none' } }, (lit ? '\u2713 ' : '\u00B7 ') + c);
          }))),
      // signed receipt capsule — born at gate, travels down across Crossing
      (() => {
        const born = C.FATE + 4.6;
        const y0 = 1244, y1 = 1330;
        const t1 = MOTION.draw(T, C.Crossing, 3.2);
        const y = y0 + (y1 - y0 + 60) * t1;
        const op = T < born ? 0 : Math.min(1, (T - born) / 0.6) * (T > C.URP + 1.5 ? Math.max(0, 1 - (T - C.URP - 1.5) / 0.8) : 1);
        return h('div', { style: { position: 'absolute', left: 960 - 170, top: y, width: 340, opacity: op, textAlign: 'center' } },
          h('div', { style: { display: 'inline-block', fontFamily: MONO, fontSize: 15, color: INK, background: GOLD, borderRadius: 24, padding: '10px 22px', boxShadow: '0 0 34px rgba(201,169,98,.45)' } }, '\u2709 SIGNED RECEIPT \u00B7 sha:9e59\u20268d'),
          h('div', { style: { fontFamily: SANS, fontSize: 14.5, color: DIM, marginTop: 8 } }, 'minimum disclosure \u2014 raw memory never crosses'));
      })());
  }

  function Urp({ T, C }) {
    const els = [];
    els.push(h('div', { key: 'fr', style: { position: 'absolute', left: 90, top: 1300, width: 1740, height: 3980, border: `1.5px solid rgba(91,174,127,${0.15 + 0.25 * MOTION.draw(T, C.URP, 2)})`, borderRadius: 20, opacity: MOTION.draw(T, C.URP, 1.5) } }));
    els.push(h('div', { key: 'hd', style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 1336, textAlign: 'center' }, MOTION.enter(T, C.URP + 0.3)) },
      h('div', { style: { fontFamily: SERIF, fontSize: 54, color: PARCH } }, 'BIZRA URP \u2014 the shared world'),
      h('div', { style: { fontFamily: SANS, fontSize: 17, color: DIM, marginTop: 4 } }, 'Universal Resource Plane \u2014 Node0 builds it locally first, then joins it as member #0. No one owns it.')));
    // constitution bar
    const canon = ['Third Fact protocol', 'Ihs\u0101n \u00B7 \u0625\u062D\u0633\u0627\u0646', '\u02BFAdl \u00B7 \u0639\u062F\u0644 (Gini \u2264 0.35)', 'Riba-zero \u2014 no usury', 'Zann-zero \u2014 no overclaim'];
    els.push(h('div', { key: 'cn', style: { position: 'absolute', left: 210, top: 1462, width: 1500, display: 'flex', gap: 12 } },
      canon.map((c, i) => h('div', { key: i, style: Object.assign({ flex: 1, border: `1px solid rgba(201,169,98,.4)`, borderRadius: 8, padding: '11px 10px', textAlign: 'center', fontFamily: SANS, fontSize: 15.5, color: GOLD, background: 'rgba(201,169,98,.05)' }, MOTION.pop(T, C.URP + 1.2 + i * 0.35)) }, c))));
    els.push(h('div', { key: 'cnl', style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 1432, textAlign: 'center' }, MOTION.enter(T, C.URP + 1)) , }, label('Constitution \u2014 the root canon', {})));
    // admission
    els.push(h('div', { key: 'ad', style: Object.assign({ position: 'absolute', left: 460, top: 1548, width: 1000, textAlign: 'center', fontFamily: SANS, fontSize: 16, color: DIM }, MOTION.enter(T, C.URP + 3.2)) },
      'admission: principal identity \u00B7 challenge\u2013response \u00B7 replay guard \u00B7 quarantine \u00B7 revocation'));
    // SAT
    const sats = [['SAT-1', 'Boundary Verifier'], ['SAT-2', 'Consent Auditor'], ['SAT-3', 'Doctrine Compliance'], ['SAT-4', 'Receipt-Chain Verifier'], ['SAT-5', 'Identity Verifier']];
    els.push(h('div', { key: 'st', style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 1660, textAlign: 'center' }, MOTION.enter(T, C.SAT + 0.2)) },
      h('div', { style: { fontFamily: SERIF, fontSize: 40, color: PARCH } }, 'SAT \u00D7 5 \u2014 System Agentic Team'),
      h('div', { style: { fontFamily: SANS, fontSize: 16, color: DIM, marginTop: 2 } }, 'serves the constitution \u2014 never the machine that hosts it \u00B7 every new node adds 5 more')));
    els.push(h('div', { key: 'sr', style: { position: 'absolute', left: 260, top: 1756, width: 1400, display: 'flex', gap: 14 } },
      sats.map((s, i) => h('div', { key: s[0], style: Object.assign({ flex: 1, border: `1px solid ${LINE}`, borderRadius: 10, background: CARD, padding: '14px 10px', textAlign: 'center' }, MOTION.pop(T, C.SAT + 0.8 + i * 0.45)) },
        h('div', { style: { fontFamily: MONO, fontSize: 13, color: GREEN, letterSpacing: '.14em' } }, s[0]),
        h('div', { style: { fontFamily: SANS, fontSize: 16.5, fontWeight: 600, color: PARCH, marginTop: 6, lineHeight: 1.25 } }, s[1])))));
    // verdict lamps
    const lamps = [['APPROVE', GREEN, T > C.SAT + 5.6], ['REFUSE', RED, false], ['QUARANTINE', GOLD, false]];
    els.push(h('div', { key: 'vd', style: Object.assign({ position: 'absolute', left: 610, top: 1902, width: 700, display: 'flex', gap: 16, justifyContent: 'center' }, MOTION.enter(T, C.SAT + 4.4)) },
      lamps.map((l) => h('div', { key: l[0], style: { fontFamily: MONO, fontSize: 16, letterSpacing: '.18em', padding: '10px 22px', borderRadius: 24, border: `1.5px solid ${l[2] ? l[1] : LINE}`, color: l[2] ? l[1] : FAINT, background: l[2] ? 'rgba(91,174,127,.1)' : 'transparent', boxShadow: l[2] ? `0 0 26px rgba(91,174,127,.25)` : 'none' } }, (l[2] ? '\u25CF ' : '\u25CB ') + l[0]))));
    return h('div', null, els);
  }

  function Resources({ T, C }) {
    const pools = [
      ['Compute pool', 'CPU \u00B7 GPU \u00B7 RAM \u00B7 storage \u00B7 bandwidth \u2014 pledged by nodes, never seized'],
      ['Knowledge pool', 'verified facts \u00B7 graphs \u00B7 embeddings \u00B7 skills \u00B7 receipts of what worked'],
      ['Model pool', 'local LLMs \u00B7 specialist SLMs \u00B7 expert adapters \u00B7 heterogeneous, replaceable'],
    ];
    const crit = ['capability', 'cost', 'privacy', 'reputation', 'locality', 'load'];
    return h('div', null,
      h(ZoneTitle, { y: 2140, txt: 'Shared Resources', sub: 'the pooled soil' }),
      h('div', { style: { position: 'absolute', left: 210, top: 2330, width: 1500, display: 'flex', gap: 18 } },
        pools.map((p, i) => h('div', { key: i, style: Object.assign({ flex: 1, border: `1px solid ${LINE}`, borderRadius: 12, background: CARD, padding: '20px 22px' }, MOTION.pop(T, C.Resources + 0.3 + i * 0.5)) },
          h('div', { style: { fontFamily: SERIF, fontSize: 30, color: PARCH } }, p[0]),
          h('div', { style: { fontFamily: SANS, fontSize: 15.5, color: DIM, marginTop: 8, lineHeight: 1.5 } }, p[1])))),
      h(Arrow, { x: 960, y: 2482, hgt: 60, T, at: C.Resources + 2.2 }),
      h('div', { style: Object.assign({ position: 'absolute', left: 560, top: 2552, width: 800, border: `1.5px solid rgba(201,169,98,.5)`, borderRadius: 12, background: 'rgba(201,169,98,.05)', padding: '18px 26px', textAlign: 'center' }, MOTION.pop(T, C.Resources + 2.8)) },
        h('div', { style: { fontFamily: SERIF, fontSize: 34, color: GOLD } }, 'URP Scheduler'),
        h('div', { style: { display: 'flex', gap: 10, justifyContent: 'center', marginTop: 10, flexWrap: 'wrap' } },
          crit.map((c, i) => h('span', { key: c, style: Object.assign({ fontFamily: MONO, fontSize: 14, color: DIM, border: `1px solid ${LINE}`, borderRadius: 16, padding: '5px 14px' }, MOTION.enter(T, C.Resources + 3.4 + i * 0.28, 0.5, 8)) }, c)))));
  }

  function Marketplace({ T, C }) {
    const cols = [
      ['Agent-as-a-Service', 'AaaS', ['research agents', 'coding agents', 'domain experts \u00B7 legal, security', 'specialist PAT skills for hire']],
      ['Result-as-a-Service', 'RaaS', ['verified answers & analyses', 'generated artifacts', 'solved missions', 'proof packages']],
    ];
    return h('div', null,
      h(ZoneTitle, { y: 2860, txt: 'The Marketplace', sub: 'agents & results as services' }),
      h('div', { style: { position: 'absolute', left: 310, top: 3050, width: 1300, display: 'flex', gap: 24 } },
        cols.map((c, i) => h('div', { key: i, style: Object.assign({ flex: 1, border: `1px solid ${LINE}`, borderRadius: 12, background: CARD, padding: '22px 26px' }, MOTION.pop(T, C.Marketplace + 0.3 + i * 0.6)) },
          h('div', { style: { display: 'flex', alignItems: 'baseline', gap: 12 } },
            h('div', { style: { fontFamily: SERIF, fontSize: 32, color: PARCH } }, c[0]),
            h('div', { style: { fontFamily: MONO, fontSize: 14, color: GOLD, letterSpacing: '.16em' } }, c[1])),
          c[2].map((l, j) => h('div', { key: j, style: Object.assign({ fontFamily: SANS, fontSize: 16, color: DIM, padding: '7px 0', borderTop: `1px solid rgba(248,246,241,.07)`, marginTop: j ? 0 : 10 }, MOTION.enter(T, C.Marketplace + 1.4 + i * 0.6 + j * 0.35, 0.5, 8)) }, '\u2014 ' + l))))),
      h(Arrow, { x: 960, y: 3316, hgt: 44, T, at: C.Marketplace + 4.4 }),
      h('div', { style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 3374, textAlign: 'center' }, MOTION.enter(T, C.Marketplace + 4.9)) },
        h('span', { style: { fontFamily: MONO, fontSize: 15, letterSpacing: '.18em', color: PARCH, border: `1px solid ${LINE}`, borderRadius: 20, padding: '9px 22px' } }, 'BOUNDED EXECUTION \u2014 sandboxed \u00B7 budgeted \u00B7 revocable')));
  }

  function Proof({ T, C }) {
    const steps = ['action', 'evidence', 'receipt', 'independent verification'];
    const axes = ['outcome', 'quality', 'usefulness', 'efficiency', 'novelty', 'anti-gaming'];
    const fill = MOTION.draw(T, C.Proof + 3.6, 2.4);
    return h('div', null,
      h(ZoneTitle, { y: 3470, txt: 'Proof of Impact', sub: 'the trust plane' }),
      h('div', { style: { position: 'absolute', left: 210, top: 3660, width: 1500, display: 'flex', gap: 0, alignItems: 'center' } },
        steps.map((s, i) => h(React.Fragment, { key: s },
          h('div', { style: Object.assign({ flex: 1, border: `1px solid ${LINE}`, borderRadius: 10, background: CARD, padding: '16px 8px', textAlign: 'center', fontFamily: SANS, fontSize: 17.5, fontWeight: 600, color: PARCH }, MOTION.pop(T, C.Proof + 0.3 + i * 0.55)) }, s),
          i < steps.length - 1 ? h('div', { style: { width: 46, textAlign: 'center', fontFamily: MONO, fontSize: 20, color: GOLD, opacity: MOTION.draw(T, C.Proof + 0.6 + i * 0.55, 0.4) } }, '\u2192') : null))),
      h('div', { style: Object.assign({ position: 'absolute', left: 360, top: 3790, width: 1200, border: `1.5px solid rgba(91,174,127,.5)`, borderRadius: 12, background: 'rgba(91,174,127,.05)', padding: '18px 26px' }, MOTION.enter(T, C.Proof + 3.2)) },
        h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' } },
          h('div', { style: { fontFamily: SERIF, fontSize: 32, color: GREEN } }, 'Was it actually useful?'),
          h('div', { style: { fontFamily: MONO, fontSize: 15, color: fill > 0.9 ? GREEN : FAINT, letterSpacing: '.14em' } }, fill > 0.9 ? 'IMPACT VERIFIED \u2713' : 'measuring\u2026')),
        h('div', { style: { display: 'flex', gap: 10, marginTop: 14 } },
          axes.map((a, i) => h('div', { key: a, style: { flex: 1 } },
            h('div', { style: { height: 10, borderRadius: 5, background: 'rgba(248,246,241,.09)', overflow: 'hidden' } },
              h('div', { style: { height: '100%', width: `${clamp(fill * 6 - i, 0, 1) * 100}%`, background: GREEN, borderRadius: 5 } })),
            h('div', { style: { fontFamily: MONO, fontSize: 12.5, color: FAINT, marginTop: 6, textAlign: 'center' } }, a))))),
      h('div', { style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 3946, textAlign: 'center' }, MOTION.enter(T, C.Proof + 6.4)) },
        h('span', { style: { fontFamily: MONO, fontSize: 15, letterSpacing: '.16em', color: RED } }, 'NOT USEFUL \u2192 NO REWARD \u00B7 '),
        h('span', { style: { fontFamily: MONO, fontSize: 15, letterSpacing: '.16em', color: GREEN } }, 'VERIFIED IMPACT \u2192 IMPACT RECEIPT')));
  }

  function Tokens({ T, C }) {
    const cards = [
      ['Resource token', 'pays for what was spent', 'compute \u00B7 storage \u00B7 bandwidth \u00B7 agent runtime', GOLD],
      ['Impact token', 'rewards what was proven useful', 'verified knowledge \u00B7 PoI-qualified results \u00B7 reusable value', GREEN],
    ];
    return h('div', null,
      h(ZoneTitle, { y: 4080, txt: 'The Dual-Token Rail', sub: 'value settlement' }),
      h('div', { style: { position: 'absolute', left: 360, top: 4270, width: 1200, display: 'flex', gap: 24 } },
        cards.map((c, i) => h('div', { key: i, style: Object.assign({ flex: 1, border: `1.5px solid ${c[3]}55`, borderRadius: 12, background: CARD, padding: '20px 26px' }, MOTION.pop(T, C.Tokens + 0.3 + i * 0.6)) },
          h('div', { style: { fontFamily: SERIF, fontSize: 32, color: c[3] } }, c[0]),
          h('div', { style: { fontFamily: SANS, fontSize: 16.5, color: PARCH, marginTop: 4 } }, c[1]),
          h('div', { style: { fontFamily: SANS, fontSize: 15, color: DIM, marginTop: 8, lineHeight: 1.5 } }, c[2])))),
      h(Arrow, { x: 960, y: 4436, hgt: 40, T, at: C.Tokens + 2.4 }),
      h('div', { style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 4490, textAlign: 'center' }, MOTION.enter(T, C.Tokens + 3)) },
        h('div', { style: { fontFamily: SERIF, fontSize: 28, color: PARCH } }, 'Proof gates issuance.'),
        h('div', { style: { fontFamily: SANS, fontSize: 16, color: DIM, marginTop: 6 } }, 'cost alone \u2260 impact \u00B7 execution \u2260 reward \u00B7 simulation \u2260 mint \u00B7 no riba \u00B7 no speculation-first')));
    }

  function BlockGraph({ T, C }) {
    const nodes = [[560, 4760], [760, 4726], [960, 4770], [1160, 4730], [1360, 4762], [660, 4838], [1060, 4844], [1260, 4834], [860, 4852]];
    const edges = [[0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 8], [2, 6], [6, 7], [7, 4], [1, 8], [8, 6]];
    const p = MOTION.draw(T, C.BlockGraph + 0.3, 2.6);
    return h('div', null,
      h(ZoneTitle, { y: 4580, txt: 'The BlockGraph', sub: "the world's memory" }),
      h('svg', { width: 1920, height: 5400, style: { position: 'absolute', left: 0, top: 0, pointerEvents: 'none' } },
        edges.map((e, i) => {
          const vis = clamp(p * edges.length - i, 0, 1);
          const a = nodes[e[0]], b = nodes[e[1]];
          return h('line', { key: i, x1: a[0], y1: a[1], x2: a[0] + (b[0] - a[0]) * vis, y2: a[1] + (b[1] - a[1]) * vis, stroke: 'rgba(201,169,98,.45)', strokeWidth: 1.5 });
        }),
        nodes.map((n, i) => h('circle', { key: 'n' + i, cx: n[0], cy: n[1], r: 7 * clamp(p * nodes.length - i * 0.7, 0, 1), fill: i % 3 ? '#8A6B2E' : GOLD }))),
      h('div', { style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 4896, textAlign: 'center', fontFamily: SANS, fontSize: 16, color: DIM }, MOTION.enter(T, C.BlockGraph + 2.6)) },
        'receipts \u00B7 identities \u00B7 verdicts \u00B7 impact \u00B7 lineage \u2014 sealed, linked, replayable'),
      h('div', { style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 4936, textAlign: 'center', fontFamily: MONO, fontSize: 14.5, letterSpacing: '.1em', color: GOLD }, MOTION.enter(T, C.BlockGraph + 3.6)) },
        'THIRD FACT: mind proposes \u00B7 logic tests \u00B7 crypto seals \u00B7 receipts preserve \u00B7 human consents'));
  }

  function Learning({ T, C }) {
    const steps = ['verified reward', 'RL improves policy', 'better routing & agents', 'RSI proposal', 'test \u00B7 compare \u00B7 prove', 'adopt or reject'];
    const cx = 960, cy = 5130, R = 118;
    const active = Math.floor(Math.max(0, T - C.Learning) / 1.35) % steps.length;
    const vis = MOTION.draw(T, C.Learning + 0.2, 1.2);
    return h('div', null,
      h('div', { style: { position: 'absolute', left: cx - R - 14, top: cy - R - 14, width: (R + 14) * 2, height: (R + 14) * 2, borderRadius: '50%', border: `1.5px dashed rgba(91,174,127,${0.5 * vis})` } }),
      h('div', { style: { position: 'absolute', left: cx - 130, top: cy - 30, width: 260, textAlign: 'center', opacity: vis } },
        h('div', { style: { fontFamily: SERIF, fontSize: 32, color: GREEN } }, 'Verified learning'),
        h('div', { style: { fontFamily: MONO, fontSize: 13, color: FAINT, letterSpacing: '.14em', marginTop: 2 } }, 'RL + BOUNDED RSI')),
      steps.map((s, i) => {
        const ang = -Math.PI / 2 + i * (Math.PI * 2 / steps.length);
        const x = cx + Math.cos(ang) * (R + 150), y = cy + Math.sin(ang) * (R + 62);
        const isOn = T > C.Learning && i === active;
        return h('div', { key: s, style: Object.assign({ position: 'absolute', left: x - 130, top: y - 22, width: 260, textAlign: 'center', fontFamily: SANS, fontSize: 16.5, fontWeight: isOn ? 700 : 400, color: isOn ? GREEN : DIM, border: `1px solid ${isOn ? 'rgba(91,174,127,.6)' : LINE}`, borderRadius: 22, padding: '9px 6px', background: isOn ? 'rgba(91,174,127,.08)' : CARD }, MOTION.pop(T, C.Learning + 0.4 + i * 0.3)) }, s);
      }),
      h('div', { style: Object.assign({ position: 'absolute', left: 0, width: 1920, top: 5326, textAlign: 'center', fontFamily: SANS, fontSize: 16.5, color: DIM }, MOTION.enter(T, C.Learning + 4.5)) },
        'The system may propose its own upgrades \u2014 but no improvement is adopted on its own word. Only what survives proof.'));
  }

  // ---------- fixed overlays ----------
  function Opening({ T, C }) {
    const gone = clamp((T - (C.Human - 0.8)) / 1.2, 0, 1);
    if (gone >= 1) return null;
    const CIRCS = [[0, 0], [0, -34], [29.4, -17], [29.4, 17], [0, 34], [-29.4, 17], [-29.4, -17]];
    const PETALS = ['M0 -34 Q17 -17 0 0 Q-17 -17 0 -34', 'M29.4 -17 Q14.7 8.5 0 0 Q14.7 -8.5 29.4 -17', 'M29.4 17 Q14.7 8.5 0 0 Q14.7 25.5 29.4 17', 'M0 34 Q-17 17 0 0 Q17 17 0 34', 'M-29.4 17 Q-14.7 8.5 0 0 Q-14.7 25.5 -29.4 17', 'M-29.4 -17 Q-14.7 8.5 0 0 Q-14.7 -8.5 -29.4 -17'];
    const nq = MOTION.draw(T, 2.7, 0.8);
    return h('div', { style: { position: 'absolute', inset: 0, background: INK, opacity: 1 - gone, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 30 } },
      h('svg', { width: 235, height: 215, viewBox: '0 0 200 190', style: { overflow: 'visible' } },
        h('defs', null,
          h('linearGradient', { id: 'bzOpenGold', x1: '0%', y1: '100%', x2: '100%', y2: '0%' },
            h('stop', { offset: '0%', stopColor: '#8A6B2E' }),
            h('stop', { offset: '50%', stopColor: GOLD }),
            h('stop', { offset: '100%', stopColor: '#F9F1D8' }))),
        h('g', { transform: 'translate(100, 95)' },
          h('circle', { r: 68, fill: 'none', stroke: 'rgba(201,169,98,.18)', strokeWidth: 0.5, strokeDasharray: '4 4', opacity: MOTION.draw(T, 0.2, 1) }),
          CIRCS.map((c, i) => { const d = MOTION.draw(T, 0.3 + i * 0.16, 1.5); return h('circle', { key: i, cx: c[0], cy: c[1], r: 34, fill: 'none', stroke: 'rgba(201,169,98,' + (i ? '.4' : '.55') + ')', strokeWidth: i ? 0.9 : 1.1, strokeDasharray: 214, strokeDashoffset: 214 * (1 - d) }); }),
          PETALS.map((p, i) => { const d = MOTION.draw(T, 1.7 + i * 0.13, 1.1); return h('path', { key: 'p' + i, d: p, fill: 'none', stroke: 'url(#bzOpenGold)', strokeWidth: 1.6, strokeLinecap: 'round', strokeDasharray: 96, strokeDashoffset: 96 * (1 - d) }); }),
          h('rect', { x: -4, y: -4, width: 8, height: 8, fill: 'url(#bzOpenGold)', transform: 'rotate(45) scale(' + nq + ')', opacity: nq }))),
      h('div', { style: Object.assign({ fontFamily: SERIF, fontSize: 128, fontWeight: 600, letterSpacing: '.22em', marginLeft: '.22em', lineHeight: 1, marginTop: 18, background: 'linear-gradient(180deg, #F9F1D8, #C9A962 55%, #8A6B2E)', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent' }, MOTION.enter(T, 1.8, 1.1)) }, 'BIZRA'),
      h('div', { style: Object.assign({ fontFamily: "'Amiri', serif", fontSize: 26, color: 'rgba(201,169,98,.65)', marginTop: 8 }, MOTION.enter(T, 2.4, 1)) }, '\u0627\u0644\u0628\u0630\u0631\u0629'),
      h('div', { style: Object.assign({ fontFamily: SANS, fontSize: 26, color: DIM, marginTop: 18 }, MOTION.enter(T, 2.6, 1)) }, 'How a sovereign intelligence node works \u2014 from intention to verified impact'),
      h('div', { style: Object.assign({ fontFamily: MONO, fontSize: 15, letterSpacing: '.3em', color: GOLD, marginTop: 22, textTransform: 'uppercase' }, MOTION.enter(T, 3.4, 1)) }, 'one seed \u00B7 one loop \u00B7 one shared world'));
  }

  function Finale({ T, C, TOTAL, arabic }) {
    const inF = MOTION.draw(T, C.Forest + 1.6, 1);
    const fadeOut = MOTION.draw(T, TOTAL - 1.6, 1.4);
    return h('div', { style: { position: 'absolute', inset: 0, zIndex: 28, pointerEvents: 'none' } },
      h('div', { style: { position: 'absolute', left: 0, right: 0, top: 84, textAlign: 'center', opacity: inF * (1 - fadeOut) } },
        h('div', { style: { fontFamily: SERIF, fontSize: 58, color: PARCH } }, 'Every human a node. Every node a seed.'),
        arabic ? h('div', { style: { fontFamily: "'Amiri', serif", fontSize: 36, color: GOLD, marginTop: 12 } }, '\u0634\u062C\u0631\u0629 \u0637\u064A\u0628\u0629 \u0623\u0635\u0644\u0647\u0627 \u062B\u0627\u0628\u062A \u0648\u0641\u0631\u0639\u0647\u0627 \u0641\u064A \u0627\u0644\u0633\u0645\u0627\u0621') : null,
        h('div', { style: { fontFamily: MONO, fontSize: 15, letterSpacing: '.16em', color: DIM, marginTop: 16 } }, 'NODE0 \u00B7 LIVE TODAY \u2014 FEDERATION \u00B7 DESIGNED, NOT YET LIVE')),
      h('div', { style: { position: 'absolute', inset: 0, background: INK, opacity: fadeOut } }));
  }

  // ================================================================ piece
  function Piece() {
    const { T, CUES: C, authoredTotal } = useComposition();
    const t = window.__bzTweaks || {};
    const arabic = t.arabicAccents !== false;
    const showCaps = t.showCaptions !== false;

    const keys = [
      [0, 960, 300, 1.0],
      [C.Human, 960, 296, 1.1], [C.Dema - 0.4, 960, 330, 1.06],
      [C.Dema + 0.4, 960, 460, 1.06], [C.PAT - 0.4, 960, 500, 1.02],
      [C.PAT + 0.5, 960, 700, 1.0], [C.Proposal - 0.4, 960, 740, 1.0],
      [C.Proposal + 0.4, 960, 950, 1.08], [C.FATE - 0.4, 960, 990, 1.04],
      [C.FATE + 0.4, 960, 1140, 1.0], [C.Crossing - 0.3, 960, 1170, 1.05],
      [C.Crossing + 0.6, 960, 1240, 1.12], [C.URP - 0.3, 960, 1370, 1.05],
      [C.URP + 0.5, 960, 1500, 0.98], [C.SAT - 0.4, 960, 1560, 0.98],
      [C.SAT + 0.5, 960, 1790, 1.0], [C.Resources - 0.4, 960, 1860, 0.98],
      [C.Resources + 0.6, 960, 2440, 0.93], [C.Marketplace - 0.4, 960, 2520, 0.93],
      [C.Marketplace + 0.6, 960, 3160, 0.93], [C.Proof - 0.4, 960, 3240, 0.95],
      [C.Proof + 0.6, 960, 3790, 0.96], [C.Tokens - 0.4, 960, 3860, 0.96],
      [C.Tokens + 0.6, 960, 4380, 0.97], [C.BlockGraph - 0.4, 960, 4440, 0.97],
      [C.BlockGraph + 0.5, 960, 4820, 1.0], [C.Learning - 0.4, 960, 4870, 0.98],
      [C.Learning + 0.5, 960, 5100, 0.96], [C.Return - 0.2, 960, 5100, 0.9],
      [C.Return + 6.4, 960, 420, 1.0], [C.Forest - 0.2, 960, 400, 0.98],
      [C.Forest + 1.6, 960, 2760, 0.184], [authoredTotal, 960, 2740, 0.181],
    ];
    const cam = camAt(T, keys);

    // spine reveal: follows the camera down, frozen full once Return begins
    const spineH = T < C.Return ? clamp(cam.y + 520, 0, 5240) - 340 : 4900;
    // verdict particle riding home
    const vp = MOTION.draw(T, C.Return + 0.4, 6.2);
    const vy = 3950 - (3950 - 470) * vp;
    const vOp = T > C.Return + 0.2 && T < C.Forest + 0.4 ? 1 : 0;

    const capItems = [
      { at: 0.8, text: 'This is how BIZRA works \u2014 one loop, from a human intention to a verified result.' },
      { at: 3.6, text: 'Follow one request through the whole system.' },
      { at: C.Human + 0.5, text: 'It begins with one human. In BIZRA, you are the node \u2014 the machine is just the soil.' },
      { at: C.Dema + 0.5, text: 'Dema is your companion and your door. It listens, explains \u2014 and never acts without you.' },
      { at: C.Dema + 4, text: 'One human, one node, a lifetime relationship.' },
      { at: C.PAT + 0.5, text: 'Behind Dema works your private team: seven Personal Agents \u2014 the PAT.' },
      { at: C.PAT + 4.6, text: 'They research, draft, remember. Everything stays on your machine.' },
      { at: C.Proposal + 0.5, text: 'The team never just acts. It writes a proposal: what, at what risk, at what cost \u2014 and how to undo it.' },
      { at: C.FATE + 0.5, text: 'Every proposal must pass FATE \u2014 the consent gate.' },
      { at: C.FATE + 3.6, text: 'Exact consent, bounded scope, an expiry, a budget. If anything is unmet, the gate fails closed.' },
      { at: C.Crossing + 0.3, text: 'Only a signed, bounded request may cross. Your raw memory never does.' },
      { at: C.URP + 0.5, text: 'It lands in the URP \u2014 the shared world every node plugs into.' },
      { at: C.URP + 4, text: 'Node0 builds this soil locally first, then joins it as member #0. No one owns it.' },
      { at: C.SAT + 0.5, text: 'Five System Agents \u2014 the SAT \u2014 verify for the constitution, not for any owner.' },
      { at: C.SAT + 4.6, text: 'They check identity, consent, doctrine and receipts \u2014 then rule: approve, refuse, or quarantine.' },
      { at: C.Resources + 0.5, text: 'Approved work is matched to shared resources: compute, knowledge and models\u2026' },
      { at: C.Resources + 4.4, text: '\u2026routed by capability, cost, privacy and reputation.' },
      { at: C.Marketplace + 0.5, text: 'Here, agents and results are services: Agent-as-a-Service, Result-as-a-Service.' },
      { at: C.Marketplace + 4.6, text: 'Execution is sandboxed, budgeted and revocable.' },
      { at: C.Proof + 0.5, text: 'Every action leaves evidence. Evidence becomes a receipt. Receipts are verified independently.' },
      { at: C.Proof + 4.8, text: 'Was it actually useful? That is Proof-of-Impact. No use \u2014 no reward.' },
      { at: C.Tokens + 0.5, text: 'Two tokens settle the work: one for resources spent, one for verified impact.' },
      { at: C.Tokens + 4.2, text: 'Proof gates issuance. No usury, no speculation-first. Value follows benefit.' },
      { at: C.BlockGraph + 0.5, text: 'Every receipt joins the BlockGraph \u2014 the world\u2019s shared memory of who did what, verified.' },
      { at: C.Learning + 0.5, text: 'Verified outcomes become the reward signal: agents, models and routing improve\u2026' },
      { at: C.Learning + 4.8, text: '\u2026and the system may propose upgrades to itself \u2014 adopted only if they survive proof.' },
      { at: C.Return + 0.5, text: 'The verdict travels home through the same gate.' },
      { at: C.Return + 4.4, text: 'Dema explains it. Your team learns. The loop closes \u2014 and begins again.' },
      { at: C.Forest + 0.4, text: 'One loop, one node \u2014 a seed.' },
      { at: C.Forest + 3.6, until: authoredTotal - 1.2, text: 'Node0 is live today. The forest is designed \u2014 and coming.' },
    ];

    return h('div', { 'data-screen-label': `t=${Math.floor(T)}s`, style: { position: 'absolute', inset: 0, background: INK, overflow: 'hidden' } },
      // ambient grain/vignette
      h('div', { style: { position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 70% 60% at 50% 42%, rgba(201,169,98,.05), transparent 70%)' } }),
      // world
      h('div', { style: { position: 'absolute', left: 0, top: 0, width: 1920, height: 5400, transformOrigin: '0 0', transform: `translate(${960 - cam.x * cam.s}px, ${540 - cam.y * cam.s}px) scale(${cam.s})` } },
        // zone tints
        h('div', { style: { position: 'absolute', left: 0, top: 0, width: 1920, height: 1040, background: 'linear-gradient(180deg, rgba(248,246,241,.025), transparent)' } }),
        h(ZoneTitle, { y: 30, txt: 'The Personal Plane', sub: 'private \u00B7 local-first \u00B7 sovereign' }),
        // spine
        h('div', { style: { position: 'absolute', left: 959, top: 340, width: 2, height: Math.max(0, spineH), background: 'linear-gradient(180deg, rgba(201,169,98,.0), rgba(201,169,98,.35) 8%, rgba(201,169,98,.35) 92%, rgba(201,169,98,0))' } }),
        h(Personal, { T, C }),
        h(Fate, { T, C }),
        h(Urp, { T, C }),
        h(Resources, { T, C }),
        h(Marketplace, { T, C }),
        h(Proof, { T, C }),
        h(Tokens, { T, C }),
        h(BlockGraph, { T, C }),
        h(Learning, { T, C }),
        // verdict particle
        h('div', { style: { position: 'absolute', left: 960 - 9, top: vy, width: 18, height: 18, borderRadius: '50%', background: GREEN, boxShadow: '0 0 30px rgba(91,174,127,.8)', opacity: vOp } }),
        vOp ? h('div', { style: { position: 'absolute', left: 990, top: vy - 8, fontFamily: MONO, fontSize: 15, color: GREEN, letterSpacing: '.12em', whiteSpace: 'nowrap' } }, 'VERIFIED VERDICT + RECEIPT') : null),
      h(Opening, { T, C }),
      h(Finale, { T, C, TOTAL: authoredTotal, arabic }),
      showCaps ? h('div', { style: { position: 'absolute', left: 0, right: 0, bottom: 34, display: 'flex', justifyContent: 'center', zIndex: 40 } },
        h('div', { style: { maxWidth: 1150, textAlign: 'center', fontFamily: SANS, fontSize: 29, lineHeight: 1.4, color: PARCH, textShadow: '0 2px 24px rgba(6,8,7,.9), 0 0 8px rgba(6,8,7,.9)' } },
          h(Captions, { items: capItems }))) : null);
  }

  // ================================================================ app
  function BizraApp() {
    const { useTweaks, TweaksPanel, TweakSection, TweakToggle } = window;
    const [t, setTweak] = useTweaks(window.__bzDefaults);
    window.__bzTweaks = t;
    return h('div', { style: { width: '100%', height: '100%', background: INK } },
      h(CompositionStage, { width: 1920, height: 1080, bg: INK, scenes: window.OM_SCENES, playback: window.OM_PLAYBACK },
        h(Piece)),
      h(TweaksPanel, null,
        h(TweakSection, { label: 'Walkthrough' }),
        h(TweakToggle, { label: 'Captions', value: t.showCaptions, onChange: (v) => setTweak('showCaptions', v) }),
        h(TweakToggle, { label: 'Arabic accents', value: t.arabicAccents, onChange: (v) => setTweak('arabicAccents', v) }),
        h(TweakSection, { label: 'Editing' }),
        h(TweakToggle, { label: 'Motion editor', value: t.motionEditor, onChange: (v) => setTweak('motionEditor', v) })));
  }

  window.BizraApp = BizraApp;
})();
