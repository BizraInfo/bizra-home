repo: BizraInfo/Dema
branch: main
note: primary of three repos — award-winner-design and bizra-data-lake are siblings under BizraInfo

## Last sync
date: 2026-08-11
commit: (unknown — GitHub API blocked: unverified_user_email on the GitHub account; all reads via user-attached local folder mounts)

### Updated in this project
- Unified three-repo evaluation and merge ruling published (BIZRA Unified Eval.dc.html)
- Public suite + Realm product layer built from Dema's docs, CLI truth, and root canon
- award-winner-design surveyed via local mount (271+ entries); data-lake mount not accessible

## Screen map
| Screen | Source |
| --- | --- |
| BIZRA Unified Eval.dc.html | Dema/docs (canon, registers) · award-winner-design (ARCHITECTURE.md, package.json, lib/constitutional-constants.ts, app/, components/) |
| BIZRA Get Started.dc.html | Dema/README.md, scripts/install |
| BIZRA Docs.dc.html | Dema/docs shelf |
| BIZRA Lab.dc.html | Dema proof matrix + audits |
| Realm pages (12) | Dema CLI/FATE/receipt semantics |
