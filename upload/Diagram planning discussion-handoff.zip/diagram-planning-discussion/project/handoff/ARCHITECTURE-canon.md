# BIZRA App Architecture (canon rewrite — migration step 04)

> Drafted in the studio for `award-winner-design/ARCHITECTURE.md`.
> Same components, canon vocabulary. Every layer carries a truth label.
> Rule inherited from the Root Source: no element may be promoted past its label.

## What this system is

The **BIZRA App** is the Next.js face of a sovereign personal node. It renders
state; it does not own it. The engine (Dema) owns law and effects:
**intelligence proposes, FATE authorizes, SAT verifies, receipts remember.**

It is not an AGI, not a consciousness, and not a religious authority —
the Root Canon's IS/IS-NOT table binds this repository too.

## Layers (was: "L0–L8 Consciousness Stack")

| Layer | Component | What it actually is | Truth label |
| --- | --- | --- | --- |
| UI | Glass interface, lifecycle router | Next 16 / React 19 app shell; TrustSite → Genesis → Teach → Assembly → CommandCenter | IMPLEMENTED |
| UI | 3D citadel (three.js) | Visualization of node state — presentation, never evidence | IMPLEMENTED |
| Gateway | API routes | The threshold between view and engine; no effect originates here | IMPLEMENTED |
| State | Genesis state machine | Deterministic lifecycle states persisted locally | IMPLEMENTED |
| Ledger | Receipt chain (via Dema) | sha256 content-addressed, append-only | MEASURED (local tiers) |
| Consensus | Proof-of-Impact | Contribution → verification → impact → reward eligibility | DESIGNED — mint path BLOCKED (`mint_allowed:false`, enforced) |
| Safety | Guardrails / FATE | Fail-closed consent + capability bounds | Consent MEASURED · EffectCap DESIGNED |
| Models | Router → local inference | Thompson-sampling router to Ollama/vLLM | DESIGNED — local inventory MEASURED |
| Observability | Metrics pipeline | Prometheus/Grafana wiring | PLANNED |

Constants parity: `lib/constitutional-constants.ts` mirrors the engine —
IHSAN 0.95 production / 0.99 strict / 0.85 gate · SNR 0.85 / T1 0.95 ·
Gini ceiling 0.35 (hard invariant). This file is the good pattern: keep it generated, never hand-drifted.

## Renames applied (vocabulary, not components)

- "Layered Consciousness Stack" → **layered runtime** (table above)
- "Sacred Geometry Engine deriving cryptographic seeds" → **deterministic
  constants module**; the Seed-of-Life remains brand geometry, and crypto
  seeds come from audited CSPRNGs — never from symbolism
- "World's First AGI / Mathematical Consciousness" → removed; capability
  claims route to the generated claim register in Dema
- "The Observer / The Soul / The Mind" → user, engine, model layer

## Boundaries this app must render, not decide

- No consequential effect without a typed FATE covenant (exact string)
- UNKNOWN renders unresolved — never green, never rounded up
- Numeric surfaces carry TruthChips (MEASURED / DESIGNED / SAMPLE)
- Wallet/economy surfaces stay dormant behind the enforced mint block

## Next steps (unchanged in substance)

1. Port AegisValidator from simulation to the engine — label stays DESIGNED until probed
2. Connect EvidencePack components to real metrics — PLANNED
3. Apply studio design tokens (`handoff/bizra-tokens.css`) over the default theme
