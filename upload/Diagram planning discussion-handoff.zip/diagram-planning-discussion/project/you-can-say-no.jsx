/* VIDEO 1 — "You Can Say No" — after 1984, answered. */
const { CompositionStage, useComposition, Shot, Easing, animate, clamp,
        useTweaks, TweaksPanel, TweakSection, TweakToggle } = window;

const fract = x => x - Math.floor(x);
const rnd = i => fract(Math.sin(i * 127.1) * 43758.5453);
const MOTION = {
  draw: (T, t0, d, ease) => (ease || Easing.easeInOutSine)(clamp((T - t0) / d, 0, 1)),
  enter: (T, t0, d) => { const p = Easing.easeOutCubic(clamp((T - t0) / d, 0, 1)); return { opacity: p, transform: `translateY(${(1 - p) * 26}px)` }; },
  pop: (T, t0, d) => Easing.easeOutBack(clamp((T - t0) / d, 0, 1))
};
const GOLD = '#C9A962', PAPER = '#FAF7F0', INK = '#10131A';
const WORDS = ['EXPERTS WARN', 'TOO LATE', 'TRUST US', 'REGULATE NOW', 'INEVITABLE', 'STAY SAFE', 'OBEY', 'ALIGNMENT', 'CONTROL', 'THE END', 'BE AFRAID', 'DO NOT ASK'];

function Screen({ i, x, y, rot, T, CUES }) {
  const col = i % 7, row = (i / 7) | 0;
  const deathT = CUES.OneStands + 2 + Math.abs(col - 4.8) * 0.22 + Math.abs(row - 1) * 0.35;
  const dead = MOTION.draw(T, deathT, 0.45, Easing.easeOutQuad);
  const flick = 0.72 + 0.28 * Math.sin(T * (5 + rnd(i) * 8) + i * 9);
  const op = flick * (1 - dead * 0.97);
  const mouth = 3 + 6 * Math.abs(Math.sin(T * (7 + rnd(i) * 6) + i));
  const word = WORDS[(i * 3 + Math.floor(T / 1.4)) % WORDS.length];
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: 232, height: 142, transform: `rotate(${rot}deg)`, background: '#04101E', border: '1px solid rgba(80,140,210,.35)', boxShadow: `0 0 ${26 * op}px rgba(60,130,220,${0.35 * op})`, opacity: Math.max(op, 0.03), overflow: 'hidden' }}>
      <div style={{ position: 'absolute', left: '50%', top: 26, transform: 'translateX(-50%)', width: 46, height: 46, borderRadius: '50%', background: '#0B2036', boxShadow: 'inset 0 -8px 14px rgba(90,160,240,.5)' }}></div>
      <div style={{ position: 'absolute', left: '50%', top: 66, transform: 'translateX(-50%)', width: 92, height: 52, borderRadius: '20px 20px 0 0', background: '#0B2036', boxShadow: 'inset 0 10px 14px rgba(90,160,240,.35)' }}></div>
      <div style={{ position: 'absolute', left: '50%', top: 52, transform: 'translateX(-50%)', width: 14, height: mouth, background: 'rgba(140,200,255,.85)' }}></div>
      <div style={{ position: 'absolute', left: 8, top: 8, width: 7, height: 7, borderRadius: '50%', background: '#F04438', opacity: 0.4 + 0.6 * Math.round(fract(T * 1.1 + rnd(i)) ) }}></div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 26, background: 'rgba(10,26,44,.92)', display: 'flex', alignItems: 'center', paddingLeft: 10, fontFamily: "'JetBrains Mono',monospace", fontSize: 12, letterSpacing: '.18em', color: 'rgba(150,200,255,.85)' }}>{word}</div>
    </div>
  );
}

function Faces({ T, CUES, wallDead }) {
  const rows = [{ y: 552, s: 0.72, n: 14 }, { y: 646, s: 0.86, n: 12 }, { y: 756, s: 1.02, n: 11 }, { y: 886, s: 1.24, n: 9 }];
  const out = [];
  rows.forEach((r, ri) => {
    for (let k = 0; k < r.n; k++) {
      if (ri === 2 && k === 7) continue; // the figure's seat
      const i = ri * 20 + k, x = 60 + k * (1800 / (r.n - 1));
      const nod = 3.5 * Math.sin(T * 1.6 + i * 1.7);
      const glow = (0.5 + 0.3 * Math.sin(T * 9 + i)) * (1 - wallDead * 0.92);
      out.push(
        <div key={i} style={{ position: 'absolute', left: x, top: r.y, transform: `scale(${r.s}) rotate(${nod}deg)`, transformOrigin: '50% 100%' }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#0A1626', margin: '0 auto', boxShadow: `inset 0 -10px 12px rgba(90,160,240,${0.55 * glow})` }}></div>
          <div style={{ width: 76, height: 36, borderRadius: '18px 18px 0 0', background: '#0A1626', marginTop: -4, boxShadow: `inset 0 12px 14px rgba(90,160,240,${0.4 * glow})` }}></div>
          <div style={{ width: 22, height: 13, margin: '-8px auto 0', background: `rgba(140,200,255,${0.75 * glow})`, boxShadow: `0 0 18px rgba(120,190,255,${0.8 * glow})` }}></div>
        </div>
      );
    }
  });
  return <div>{out}</div>;
}

function Figure({ T, CUES }) {
  const fx = 1320, fy = 756;
  const sp = MOTION.draw(T, CUES.OneStands + 0.5, 1.4, Easing.easeOutCubic);
  const g = MOTION.draw(T, CUES.OneStands + 1.2, 1.2);
  const walk = MOTION.draw(T, CUES.TheWalk, 8, Easing.easeInOutSine);
  const wx = fx + 860 * walk;
  const bob = T > CUES.TheWalk ? -5 * Math.abs(Math.sin((T - CUES.TheWalk) * 3.1)) : 0;
  const sc = (1.02 + 0.1 * sp) - 0.16 * walk;
  const bodyH = 44 + 106 * sp;
  const screenOn = T < CUES.OneStands + 1.6;
  const flash = T > CUES.OneStands + 1.6 && T < CUES.OneStands + 1.78;
  const spot = MOTION.draw(T, CUES.OneStands + 2, 3);
  return (
    <div>
      <div style={{ position: 'absolute', left: wx - 250, top: fy - 420, width: 500, height: 700, background: 'radial-gradient(ellipse at 50% 12%, rgba(201,169,98,.32), transparent 62%)', opacity: spot * (1 - walk * 0.4), pointerEvents: 'none' }}></div>
      <div style={{ position: 'absolute', left: wx, top: fy + 118 - bodyH - 44, transform: `scale(${sc}) translateY(${bob}px)`, transformOrigin: '50% 100%' }}>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#060B12', margin: '0 auto', boxShadow: `inset ${-6 * g}px -8px 10px rgba(201,169,98,${0.5 * g}), 0 0 ${20 * g}px rgba(201,169,98,${0.35 * g})` }}></div>
        <div style={{ width: 56, height: bodyH, borderRadius: '24px 24px 4px 4px', background: '#060B12', margin: '-4px auto 0', boxShadow: `inset ${-8 * g}px 0 12px rgba(201,169,98,${0.45 * g}), 0 0 ${26 * g}px rgba(201,169,98,${0.28 * g})` }}></div>
      </div>
      <div style={{ position: 'absolute', left: fx - 96, top: fy + 22, width: 56, height: 36, background: screenOn ? 'rgba(140,200,255,.8)' : 'rgba(8,14,22,.9)', boxShadow: screenOn ? '0 0 26px rgba(120,190,255,.8)' : 'none', border: '1px solid rgba(80,140,210,.4)', opacity: 1 - walk }}></div>
      {flash && <div style={{ position: 'absolute', left: fx - 130, top: fy - 16, width: 130, height: 110, background: 'rgba(255,255,255,.9)', filter: 'blur(6px)' }}></div>}
    </div>
  );
}

function Piece() {
  const { T, CUES } = useComposition();
  const D = (t0, d, e) => MOTION.draw(T, t0, d, e);
  const wallDead = D(CUES.OneStands + 2, 1.6);
  // camera
  let s = 1 + 0.12 * D(0, 8) - 0.06 * D(CUES.Rows, 8) + 0.18 * D(CUES.Deafening, 6);
  const shake = 8 * D(CUES.Deafening, 6) * (1 - D(CUES.OneStands, 0.6));
  const focus = D(CUES.OneStands, 1.5, Easing.easeInOutCubic);
  s = s * (1 - focus) + 1.18 * focus;
  const walk = D(CUES.TheWalk, 8, Easing.easeInOutSine);
  const wx = 1320 + 860 * walk;
  let tx = -((1320 - 960) * 0.42) * focus - clamp(wx - 1320, 0, 620) * 0.55 * (T > CUES.TheWalk ? 1 : 0);
  let ty = -280 * D(CUES.Rows, 8) * (1 - focus) - ((756 - 540) * 0.42) * focus;
  tx += Math.sin(T * 37) * shake; ty += Math.cos(T * 29) * shake * 0.6;
  const noiseOp = (0.06 + 0.1 * D(CUES.Deafening, 6)) * (1 - wallDead);
  const blackOp = clamp(D(CUES.TheLine - 0.2, 0.5) - D(CUES.TheWalk, 1), 0, 1);
  const doorW = 620 * D(CUES.TheWalk + 1, 7);
  const flood = T < CUES.Numbers + 0.1 ? D(CUES.Numbers - 1, 1) : 0;
  const l1 = clamp(D(CUES.TheLine + 0.6, 0.8) - D(CUES.TheLine + 3.6, 0.4), 0, 1);
  const l2 = clamp(D(CUES.TheLine + 4.1, 0.8) - D(CUES.TheWalk - 0.4, 0.4), 0, 1);
  const cards = [
    { n: '3 YEARS', s: 'roots before leaves — by choice' },
    { n: '15,000 HOURS', s: 'one watchstander · no salary · no day off' },
    { n: '4 TB · 158 REPOSITORIES', s: 'local · no cloud · no api · no trust required' }
  ];
  const screens = [];
  for (let i = 0; i < 21; i++) {
    const col = i % 7, row = (i / 7) | 0;
    screens.push(<Screen key={i} i={i} x={44 + col * 268} y={44 + row * 164 + Math.abs(col - 3) * 9} rot={(col - 3) * 1.1} T={T} CUES={CUES} />);
  }
  return (
    <div data-screen-label={'t=' + Math.floor(T) + 's'} style={{ position: 'absolute', inset: 0, background: '#02060C', overflow: 'hidden', fontFamily: "'Playfair Display',Georgia,serif" }}>
      <Shot from={0} to={CUES.Numbers}>
        <div style={{ position: 'absolute', inset: 0, transform: `translate(${tx}px,${ty}px) scale(${s})`, transformOrigin: '960px 540px' }}>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 30%, rgba(40,90,160,.22), transparent 65%)', opacity: 1 - wallDead }}></div>
          {screens}
          <Faces T={T} CUES={CUES} wallDead={wallDead} />
          <Figure T={T} CUES={CUES} />
          <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: doorW, background: 'linear-gradient(270deg, #F7E9C4 0%, rgba(201,169,98,.8) 45%, transparent 100%)', opacity: 0.95, filter: 'blur(2px)' }}></div>
          <div style={{ position: 'absolute', right: -60, top: -120, width: doorW * 1.5, height: 1400, background: 'linear-gradient(260deg, rgba(247,233,196,.5), transparent 70%)', transform: 'skewX(-9deg)', opacity: D(CUES.TheWalk + 2, 6) }}></div>
        </div>
        <div style={{ position: 'absolute', inset: 0, opacity: noiseOp, background: 'repeating-linear-gradient(0deg, rgba(160,200,255,.5) 0 2px, transparent 2px 5px)', backgroundPosition: `0 ${(T * 260) % 5}px`, mixBlendMode: 'screen', pointerEvents: 'none' }}></div>
        <div style={{ position: 'absolute', inset: 0, background: '#010409', opacity: blackOp }}></div>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, opacity: Math.max(l1, l2) }}>
          <div style={{ fontSize: 46, fontStyle: 'italic', color: '#F4EFE4', textAlign: 'center', maxWidth: 1240, lineHeight: 1.5, opacity: l1 > 0 ? l1 : l2 }}>
            {l2 > l1 ? '…and expected a different result.' : 'We trained the machines on our double standard…'}
          </div>
          <div style={{ width: 60, height: 1, background: 'rgba(201,169,98,.6)' }}></div>
          <div style={{ fontFamily: "Amiri,serif", fontSize: 26, color: 'rgba(201,169,98,.8)', opacity: l1 > 0 ? l1 : l2 }} dir="rtl">
            {l2 > l1 ? '…ثم انتظرنا نتيجةً مختلفة.' : 'درّبنا الآلاتِ على ازدواجيّةِ معاييرنا…'}
          </div>
        </div>
        <div style={{ position: 'absolute', inset: 0, background: PAPER, opacity: flood }}></div>
      </Shot>
      <Shot from={CUES.Numbers} to={CUES.SayNo}>
        <div style={{ position: 'absolute', inset: 0, background: PAPER }}>
          {cards.map((c, i) => {
            const on = T >= CUES.Numbers + i * 3 && T < CUES.Numbers + (i + 1) * 3;
            const pp = MOTION.pop(T, CUES.Numbers + i * 3, 0.7);
            return on && (
              <div key={i} style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, transform: `scale(${0.94 + 0.06 * pp})` }}>
                <div style={{ width: 13, height: 13, transform: 'rotate(45deg)', background: GOLD }}></div>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontWeight: 700, fontSize: 92, letterSpacing: '.04em', color: INK }}>{c.n}</div>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 19, letterSpacing: '.22em', color: '#5B5647' }}>{c.s.toUpperCase()}</div>
              </div>
            );
          })}
        </div>
      </Shot>
      <Shot from={CUES.SayNo} to={999}>
        <div style={{ position: 'absolute', inset: 0, background: PAPER, opacity: T < CUES.SayNo + 4 ? 1 : 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28 }}>
          <div style={{ fontSize: 96, fontWeight: 600, color: INK, transform: `scale(${0.92 + 0.08 * MOTION.pop(T, CUES.SayNo, 0.9)})` }}>You can say no.</div>
          <div style={{ fontFamily: 'Amiri,serif', fontSize: 38, color: '#8B7340' }} dir="rtl">تستطيعُ أن تقول: لا</div>
        </div>
        <div style={{ position: 'absolute', inset: 0, background: '#050B14', opacity: T >= CUES.SayNo + 4 ? 1 : 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
          <svg viewBox="0 0 120 120" width="92" height="92" style={{ filter: 'drop-shadow(0 0 16px rgba(201,169,98,.5))' }}>
            {[[60, 60], [60, 41], [76.5, 50.5], [76.5, 69.5], [60, 79], [43.5, 69.5], [43.5, 50.5]].map((c, i) =>
              <circle key={i} cx={c[0]} cy={c[1]} r="19" fill="none" stroke={GOLD} strokeWidth="1.1" opacity={i ? 0.75 : 1}></circle>)}
          </svg>
          <div style={{ ...MOTION.enter(T, CUES.SayNo + 4.6, 1), fontSize: 21, color: 'rgba(248,246,241,.55)' }}>In 1984, a corporation promised a machine for the rest of us.</div>
          <div style={{ ...MOTION.enter(T, CUES.SayNo + 5.4, 1), fontSize: 30, fontStyle: 'italic', color: '#E8D5A3' }}>This one was made by one of the rest of us.</div>
          <div style={{ ...MOTION.enter(T, CUES.SayNo + 6.2, 1), fontFamily: "'JetBrains Mono',monospace", fontSize: 13, letterSpacing: '.3em', color: 'rgba(201,169,98,.8)', marginTop: 14 }}>◈ BIZRA · <span style={{ fontFamily: 'Amiri,serif', fontSize: 17 }}>بذرة</span></div>
        </div>
      </Shot>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', boxShadow: 'inset 0 0 190px rgba(0,0,0,.55)' }}></div>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.05, background: 'repeating-linear-gradient(0deg, rgba(255,255,255,.6) 0 1px, transparent 1px 3px)', backgroundPosition: `0 ${(T * 137) % 3}px` }}></div>
    </div>
  );
}

function Film() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <div style={{ width: '100%', height: '100%' }}>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#02060C">
        <Piece />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}
window.Film = Film;