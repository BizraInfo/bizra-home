import unittest
from datetime import datetime, timedelta, timezone
from bgl.audit.founder import ActivityEvent, sessionize

class TestFounderAudit(unittest.TestCase):
    def test_sessionization_is_bounded(self):
        t0 = datetime(2026,1,1,tzinfo=timezone.utc)
        events = [
            ActivityEvent(t0,"a","chat"),
            ActivityEvent(t0+timedelta(minutes=10),"b","chat"),
            ActivityEvent(t0+timedelta(minutes=30),"c","commit"),
            ActivityEvent(t0+timedelta(hours=3),"d","chat"),
        ]
        sessions = sessionize(events)
        self.assertEqual(len(sessions), 2)
        self.assertEqual(sessions[0].event_count, 3)
        self.assertEqual(sessions[0].bounded_active_seconds, 25*60)

if __name__ == "__main__":
    unittest.main()
