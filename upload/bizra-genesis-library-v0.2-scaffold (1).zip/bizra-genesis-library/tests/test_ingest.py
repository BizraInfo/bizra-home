import tempfile
import unittest
from pathlib import Path
from bgl.pipeline.ingest import ingest_directory
from bgl.pipeline.verify import verify_library
from bgl.config import ensure_layout
from bgl.db import connect

class TestIngest(unittest.TestCase):
    def test_exact_dedup_and_idempotency(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td); source = td / "source"; library = td / "library"; source.mkdir()
            (source / "a.txt").write_text("same", encoding="utf-8")
            (source / "b.txt").write_text("same", encoding="utf-8")
            (source / "c.txt").write_text("different", encoding="utf-8")
            before = {p.name: (p.read_bytes(), p.stat().st_mtime_ns) for p in source.iterdir()}
            first = ingest_directory(library, source)
            second = ingest_directory(library, source)
            p = ensure_layout(library)
            with connect(p.index / "bgl.sqlite3") as conn:
                self.assertEqual(conn.execute("SELECT COUNT(*) FROM objects").fetchone()[0], 2)
                self.assertEqual(conn.execute("SELECT COUNT(*) FROM source_locations").fetchone()[0], 3)
            self.assertEqual(first["unique_added"], 2)
            self.assertEqual(second["unique_added"], 0)
            self.assertTrue(verify_library(library)["ok"])
            after = {p.name: (p.read_bytes(), p.stat().st_mtime_ns) for p in source.iterdir()}
            self.assertEqual(before, after)

if __name__ == "__main__":
    unittest.main()
