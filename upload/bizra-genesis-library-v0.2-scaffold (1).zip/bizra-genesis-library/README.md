# BIZRA Genesis Library

BGL is a local-first canonical evidence library for the BIZRA corpus.

## Working scaffold

This package already implements the BGL-0 to BGL-3 foundation:

- initialize a library root;
- ingest a local directory without changing it;
- stream bytes through SHA-256;
- store unique objects once in a content-addressed store;
- retain every observed source location;
- re-ingest idempotently;
- generate JSON ingest receipts;
- verify stored-object integrity;
- expose founder-audit structures without economic scoring.

## Quick start

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
pip install -e .

bgl init --root "E:\BIZRA_GENESIS_LIBRARY"
bgl ingest --root "E:\BIZRA_GENESIS_LIBRARY" --source "D:\PilotSource"
bgl status --root "E:\BIZRA_GENESIS_LIBRARY"
bgl verify --root "E:\BIZRA_GENESIS_LIBRARY"
```

Start with a small pilot folder, not the full three-year estate.

## Safety boundary

The engine never deletes or rewrites source files. Exact deduplication only prevents duplicate bytes inside BGL's canonical object store.

## Development order

1. prove local ingest;
2. prove exact dedup and idempotency;
3. prove recovery and manifests;
4. add source adapters;
5. add deterministic extraction;
6. add semantic context;
7. build graph/lineage;
8. integrate proof and PoI inputs;
9. keep mint/economic activation outside BGL and separately gated.
