# Founder Genesis Audit / Contribution Ledger v0.1

## Purpose

Create a neutral retrospective evidence package for the first BIZRA contribution audit. The founder is the first subject of the rule, not an exception to it.

## Required outputs

1. GENESIS_IDENTITY_MAP
2. GENESIS_ACTIVITY_EVENT_LEDGER
3. GENESIS_ACTIVITY_SESSION_LEDGER
4. GENESIS_ARTIFACT_LEDGER
5. GENESIS_PROVENANCE_LEDGER
6. GENESIS_RIGHTS_AND_ORIGINALITY_CLASSIFICATION
7. GENESIS_CONTRIBUTION_GRAPH
8. GENESIS_RND_ASSET_REGISTER
9. GENESIS_REPLACEMENT_COST_INPUTS
10. GENESIS_STARTUP_COMPARABLE_INPUTS
11. GENESIS_INDEPENDENT_VERIFICATION_PACKAGE
12. GENESIS_POI_INPUT_RECEIPTS

## Identity resolution

Multiple accounts become identities of one actor only after evidence binds them. Never multiply contribution because one actor used multiple accounts.

## Time methodology

Do not infer full elapsed time as work. Report evidence-active days, observed event counts, session spans, bounded estimates, policy version, confidence, and caveats.

Default scaffold policy:

```text
session break: 45 minutes
max credited gap between adjacent events: 15 minutes
```

These are provisional policy values, not historical facts. Sensitivity analysis is required before valuation use.

## Contribution classes

OBSERVED, REFERENCED, ADAPTED, GENERATED, AUTHORED, IMPLEMENTED, VERIFIED, IMPACTED.

External possession/reference does not equal authored contribution.

## Valuation separation

Keep distinct: labor replacement cost, R&D/IP asset valuation, enterprise valuation, and PoI/reward eligibility.

## Economic boundary

This subsystem emits evidence and measurements only. It MUST NOT mint, allocate tokens, produce a founder entitlement, assign live reward, activate URP distribution, or treat simulated impact as economic value.
