# Architecture

```text
Sources
  -> Source adapters
  -> Discovery
  -> Staging + streaming SHA-256
  -> Exact dedup
  -> Content-addressed object store
  -> SQLite provenance/index
  -> Receipts + verification
  -> Derived/context layer
  -> Graph / lineage
  -> Independent proof consumers
```

BGL owns its object store and metadata index. Source systems are read-only during ingest. Resource scheduling, classification, taxonomy, extraction, and semantic models are policy; object identity, provenance, exact-dedup rules, and source immutability are invariant.
