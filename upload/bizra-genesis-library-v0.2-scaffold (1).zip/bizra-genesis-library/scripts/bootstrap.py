import argparse
from bgl.config import ensure_layout
from bgl.db import init_db

def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--root", required=True); args = parser.parse_args()
    p = ensure_layout(args.root); init_db(p.index / "bgl.sqlite3")
    print(f"Initialized BIZRA Genesis Library at {p.root}")

if __name__ == "__main__":
    main()
