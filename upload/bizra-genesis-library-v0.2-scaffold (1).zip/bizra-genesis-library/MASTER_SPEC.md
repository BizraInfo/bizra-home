# BIZRA Genesis Library (BGL)
## Master Technical Plan & System Specification v0.2

**Project:** `bizra-genesis-library`  
**Corpus root:** `BIZRA_GENESIS_LIBRARY/`  
**Mission:** One local-first, provenance-preserving, deduplicated, context-aware home for the complete BIZRA corpus, plus a neutral proof substrate for retrospective contribution audit.

## 1. System Identity

BGL is not merely a data lake. It is the canonical evidence library beneath future BIZRA knowledge, lineage, Proof-of-Impact, content generation, and resource coordination.

```text
ORIGINAL EVIDENCE
    -> IDENTITY + PROVENANCE
    -> EXACT DEDUP + VERSION RELATIONS
    -> INDEX + CONTEXT
    -> KNOWLEDGE + LINEAGE
    -> VERIFICATION + RECEIPTS
    -> PoI INPUT
    -> REWARD ELIGIBILITY
    -> URP ECONOMIC POLICY
    -> MINT - only when separately authorized and all gates are closed
```

## 2. Hard Core / Flexible Shell

### Immutable invariants

1. Source evidence is never silently modified.
2. Source evidence is never automatically deleted.
3. Every stored byte-object has SHA-256 identity.
4. Exact deduplication requires exact hash equality.
5. Near-duplicates and versions are never auto-deleted.
6. Every object retains all observed source locations.
7. Every derived artifact points to source object(s).
8. Pipeline execution is idempotent and restart-safe.
9. Unknown objects are preserved.
10. Every state-changing operation is auditable.

### Dynamic policy surface

Topic/project taxonomies, classifiers, embeddings, OCR/transcription, context windows, sessionization policy, near-duplicate strategies, views, thresholds, graph schemas, and scheduling may evolve through versioned policy without rewriting evidence.

## 3. Physical Root

```text
BIZRA_GENESIS_LIBRARY/
|-- 00_SYSTEM/engine/
|-- 01_INBOX/
|-- 02_OBJECTS/sha256/
|-- 03_INDEX/
|-- 04_VIEWS/
|-- 05_DERIVED/
|-- 06_GRAPH/
|-- 07_RECEIPTS/
|-- 08_QUARANTINE/
|-- 09_EXPORTS/
`-- 10_BACKUP/
```

The software repository lives in `00_SYSTEM/engine/`. Corpus bytes are never committed to Git.

## 4. Smart Ingest Pipeline

```text
DISCOVER
-> SNAPSHOT SOURCE METADATA
-> STAGE/STREAM
-> HASH
-> EXACT DEDUP CHECK
-> CONTENT-ADDRESS STORE
-> REGISTER SOURCE LOCATION
-> IDENTIFY PHYSICAL TYPE
-> INDEX
-> VERIFY
-> RECEIPT
-> OPTIONAL DERIVED EXTRACTION
-> OPTIONAL SEMANTIC CLASSIFICATION
```

Unknown is a valid state.

## 5. Canonical Object Identity

`object_id = "sha256:" + sha256(original_bytes)`

One object may have many source locations. Exact duplicates collapse storage only; provenance remains separate.

## 6. Context-Aware Classification

- L0 deterministic physical facts
- L1 source context
- L2 content-derived context
- L3 model-derived semantic context
- L4 human-reviewed correction

Semantic classifications are multi-label, versioned, confidence-bearing, and reversible as metadata.

## 7. Founder Genesis Audit

The founder is the first retrospective audit subject, not a privileged exception.

Keep separate:
1. evidence-backed activity/time;
2. founder labor replacement cost;
3. R&D/IP asset value;
4. enterprise valuation;
5. PoI/reward eligibility.

None automatically implies another.

```text
IDENTITY RESOLUTION
-> ACTIVITY EVENT LEDGER
-> SESSIONIZATION WITH DECLARED ASSUMPTIONS
-> ARTIFACT LEDGER
-> PROVENANCE / RIGHTS CLASSIFICATION
-> CONTRIBUTION GRAPH
-> R&D ASSET REGISTER
-> INDEPENDENT MARKET BENCHMARK INPUT
-> VERIFIER REVIEW
-> RECEIPTS
-> PoI-READY INPUTS
```

BGL MUST NOT mint a token, assign economic entitlement, or self-award founder compensation.

## 8. Activity-Time Measurement Rule

Never infer `last_event - first_event = hours worked`.

Report separately: evidence-active days, event counts, observed session spans, bounded activity estimates, sensitivity estimates, policy version, confidence, and missing-source caveats.

## 9. Contribution Classification

Historical assets may be labeled:

`OBSERVED | REFERENCED | ADAPTED | GENERATED | AUTHORED | IMPLEMENTED | VERIFIED | IMPACTED`

Possession of external information is not contribution.

## 10. Current Scaffold Boundary

Implemented:
- project bootstrap;
- local filesystem source adapter;
- streaming SHA-256;
- content-addressed storage;
- exact dedup;
- source provenance;
- SQLite index;
- ingest receipts;
- verification command;
- idempotent re-ingest test;
- founder-audit schema and non-economic sessionization primitive;
- CI workflow.

Deferred:
- cloud connectors;
- structured chat parsers;
- GitHub mirror/bundle adapter;
- OCR/transcription;
- embeddings/graph;
- semantic model classification;
- market valuation data;
- PoI scoring;
- live URP distribution;
- token mint.

## 11. Acceptance Contract

GREEN requires:

```text
A1 source modifications by BGL = 0
A2 source deletions by BGL = 0
A3 stored objects without SHA-256 = 0
A4 stored objects without provenance = 0
A5 re-ingest creates no new unique objects unexpectedly
A6 exact duplicate byte copies created = 0
A7 unknown objects lost = 0
A8 ingest receipt generated = TRUE
A9 store verification succeeds = TRUE
A10 founder-audit outputs remain non-economic = TRUE
```

## 12. Governing Rule

```text
Preserve first.
Identify second.
Deduplicate exactly.
Index completely.
Measure transparently.
Understand progressively.
Connect contextually.
Verify independently.
Never rewrite history.
Never infer reward from possession or time alone.
```
