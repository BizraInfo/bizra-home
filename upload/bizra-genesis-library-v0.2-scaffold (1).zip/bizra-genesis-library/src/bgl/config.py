from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class LibraryPaths:
    root: Path
    system: Path
    objects: Path
    index: Path
    receipts: Path
    quarantine: Path
    staging: Path

def paths_for(root: str | Path) -> LibraryPaths:
    root = Path(root).expanduser().resolve()
    return LibraryPaths(
        root=root,
        system=root / "00_SYSTEM",
        objects=root / "02_OBJECTS" / "sha256",
        index=root / "03_INDEX",
        receipts=root / "07_RECEIPTS",
        quarantine=root / "08_QUARANTINE",
        staging=root / "01_INBOX" / "temporary",
    )

def ensure_layout(root: str | Path) -> LibraryPaths:
    p = paths_for(root)
    for path in [
        p.system, p.objects, p.index, p.receipts, p.quarantine, p.staging,
        p.root / "04_VIEWS", p.root / "05_DERIVED", p.root / "06_GRAPH",
        p.root / "09_EXPORTS", p.root / "10_BACKUP",
    ]:
        path.mkdir(parents=True, exist_ok=True)
    return p
