import argparse
import json
from bgl.config import ensure_layout
from bgl.db import connect, init_db
from bgl.pipeline.ingest import ingest_directory
from bgl.pipeline.verify import verify_library

def cmd_init(args):
    p = ensure_layout(args.root)
    init_db(p.index / "bgl.sqlite3")
    print(json.dumps({"ok": True, "root": str(p.root)}, indent=2))

def cmd_ingest(args):
    print(json.dumps(ingest_directory(args.root, args.source), indent=2))

def cmd_status(args):
    p = ensure_layout(args.root)
    db = p.index / "bgl.sqlite3"
    init_db(db)
    with connect(db) as conn:
        result = {
            "root": str(p.root),
            "unique_objects": conn.execute("SELECT COUNT(*) FROM objects").fetchone()[0],
            "source_locations": conn.execute("SELECT COUNT(*) FROM source_locations").fetchone()[0],
            "runs": conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0],
        }
    print(json.dumps(result, indent=2))

def cmd_verify(args):
    result = verify_library(args.root)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["ok"] else 2)

def build_parser():
    parser = argparse.ArgumentParser(prog="bgl")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init"); p.add_argument("--root", required=True); p.set_defaults(func=cmd_init)
    p = sub.add_parser("ingest"); p.add_argument("--root", required=True); p.add_argument("--source", required=True); p.set_defaults(func=cmd_ingest)
    p = sub.add_parser("status"); p.add_argument("--root", required=True); p.set_defaults(func=cmd_status)
    p = sub.add_parser("verify"); p.add_argument("--root", required=True); p.set_defaults(func=cmd_verify)
    return parser

def main():
    args = build_parser().parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
