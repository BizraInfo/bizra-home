import hashlib
import os
from pathlib import Path
from uuid import uuid4

def canonical_path(objects_root: Path, sha256: str) -> Path:
    return objects_root / sha256[:2] / sha256[2:4] / sha256

def stage_and_store(source: Path, objects_root: Path, staging_root: Path, chunk_size: int = 1024 * 1024):
    staging_root.mkdir(parents=True, exist_ok=True)
    temp = staging_root / f"{uuid4().hex}.partial"
    h = hashlib.sha256()
    total = 0
    before = source.stat()
    try:
        with open(source, "rb") as src, open(temp, "xb") as dst:
            while True:
                chunk = src.read(chunk_size)
                if not chunk:
                    break
                dst.write(chunk)
                h.update(chunk)
                total += len(chunk)
            dst.flush()
            os.fsync(dst.fileno())
        after = source.stat()
        if before.st_size != after.st_size or before.st_mtime_ns != after.st_mtime_ns:
            raise RuntimeError(f"source changed during ingest: {source}")
        digest = h.hexdigest()
        final = canonical_path(objects_root, digest)
        final.parent.mkdir(parents=True, exist_ok=True)
        if final.exists():
            temp.unlink(missing_ok=True)
            return digest, total, final, False
        os.replace(temp, final)
        return digest, total, final, True
    except Exception:
        temp.unlink(missing_ok=True)
        raise
