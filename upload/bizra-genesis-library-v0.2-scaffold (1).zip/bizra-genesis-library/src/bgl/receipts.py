import hashlib
import json
from pathlib import Path

def write_receipt(path: Path, payload: dict) -> str:
    body = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    payload = dict(payload)
    payload["receipt_hash"] = "sha256:" + hashlib.sha256(body).hexdigest()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return payload["receipt_hash"]
