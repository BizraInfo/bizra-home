import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from bgl.config import ensure_layout
from bgl.db import connect, init_db
from bgl.receipts import write_receipt
from bgl.sources.filesystem import discover
from bgl.storage import stage_and_store

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def ingest_directory(library_root: str | Path, source_root: str | Path) -> dict:
    p = ensure_layout(library_root)
    db_path = p.index / "bgl.sqlite3"
    init_db(db_path)
    source_root = Path(source_root).expanduser().resolve()
    run_id = "RUN-" + uuid4().hex
    started = now_iso()
    counts = {"observed": 0, "unique_added": 0, "duplicates_linked": 0, "errors": 0}

    with connect(db_path) as conn:
        conn.execute(
            "INSERT INTO runs(run_id,pipeline,started_at,status,source) VALUES(?,?,?,?,?)",
            (run_id, "local_filesystem_ingest", started, "RUNNING", str(source_root)),
        )
        for candidate in discover(source_root):
            counts["observed"] += 1
            try:
                digest, size, final_path, added = stage_and_store(candidate.path, p.objects, p.staging)
                object_id = "sha256:" + digest
                if added:
                    counts["unique_added"] += 1
                    conn.execute(
                        """INSERT OR IGNORE INTO objects
                        (object_id,sha256,size_bytes,storage_path,first_seen_at,integrity_state)
                        VALUES(?,?,?,?,?,?)""",
                        (object_id, digest, size, str(final_path), now_iso(), "STORED"),
                    )
                else:
                    counts["duplicates_linked"] += 1
                conn.execute(
                    """INSERT OR IGNORE INTO source_locations
                    (source_location_id,object_id,provider,original_path,original_name,size_bytes,
                     source_modified_ns,observed_at)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (
                        "SRC-" + uuid4().hex, object_id, "local_filesystem",
                        str(candidate.path), candidate.path.name, candidate.size_bytes,
                        candidate.modified_ns, now_iso(),
                    ),
                )
                conn.execute(
                    """INSERT INTO events
                    (event_id,run_id,object_id,stage,action,status,timestamp,details_json)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (
                        "EV-" + uuid4().hex, run_id, object_id, "INGEST", "REGISTER",
                        "OK", now_iso(), json.dumps({"source": str(candidate.path)}),
                    ),
                )
            except Exception as exc:
                counts["errors"] += 1
                conn.execute(
                    """INSERT INTO events
                    (event_id,run_id,object_id,stage,action,status,timestamp,details_json)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (
                        "EV-" + uuid4().hex, run_id, None, "INGEST", "REGISTER",
                        "ERROR", now_iso(), json.dumps({"source": str(candidate.path), "error": repr(exc)}),
                    ),
                )

        finished = now_iso()
        receipt_path = p.receipts / "ingest" / f"{run_id}.json"
        payload = {
            "schema": "bizra.bgl.ingest_receipt.v0.2",
            "run_id": run_id,
            "pipeline": "local_filesystem_ingest",
            "source": str(source_root),
            "started_at": started,
            "finished_at": finished,
            "observed": counts["observed"],
            "unique_added": counts["unique_added"],
            "duplicates_linked": counts["duplicates_linked"],
            "errors": counts["errors"],
            "source_objects_modified_by_bgl": 0,
            "source_objects_deleted_by_bgl": 0,
        }
        receipt_hash = write_receipt(receipt_path, payload)
        conn.execute(
            """UPDATE runs SET finished_at=?,status=?,observed_count=?,unique_added=?,
            duplicates_linked=?,errors=?,receipt_path=? WHERE run_id=?""",
            (
                finished, "COMPLETE" if counts["errors"] == 0 else "COMPLETE_WITH_ERRORS",
                counts["observed"], counts["unique_added"], counts["duplicates_linked"],
                counts["errors"], str(receipt_path), run_id,
            ),
        )
    return {**payload, "receipt_path": str(receipt_path), "receipt_hash": receipt_hash}
