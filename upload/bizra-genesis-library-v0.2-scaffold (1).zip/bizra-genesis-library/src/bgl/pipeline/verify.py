from pathlib import Path
from bgl.config import ensure_layout
from bgl.db import connect, init_db
from bgl.hashing import sha256_file

def verify_library(library_root: str | Path) -> dict:
    p = ensure_layout(library_root)
    db_path = p.index / "bgl.sqlite3"
    init_db(db_path)
    checked = 0
    failed = []
    with connect(db_path) as conn:
        rows = conn.execute("SELECT object_id,sha256,storage_path,size_bytes FROM objects").fetchall()
        for object_id, expected, storage_path, expected_size in rows:
            checked += 1
            path = Path(storage_path)
            if not path.exists():
                failed.append({"object_id": object_id, "reason": "MISSING"})
                continue
            actual, size = sha256_file(path)
            if actual != expected or size != expected_size:
                failed.append({"object_id": object_id, "reason": "HASH_OR_SIZE_MISMATCH"})
    return {"schema": "bizra.bgl.verify_report.v0.2", "checked": checked, "failed": failed, "ok": not failed}
