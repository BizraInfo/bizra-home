from dataclasses import dataclass
from datetime import datetime
from typing import Iterable

@dataclass(frozen=True)
class ActivityEvent:
    event_ts: datetime
    source_ref: str
    event_type: str

@dataclass(frozen=True)
class ActivitySession:
    start_ts: datetime
    end_ts: datetime
    event_count: int
    observed_span_seconds: int
    bounded_active_seconds: int
    method: str

def sessionize(events: Iterable[ActivityEvent], inactivity_break_seconds: int = 45 * 60, max_credit_per_gap_seconds: int = 15 * 60) -> list[ActivitySession]:
    """Non-economic estimator with explicit assumptions."""
    ordered = sorted(events, key=lambda e: e.event_ts)
    if not ordered:
        return []
    groups = [[ordered[0]]]
    for event in ordered[1:]:
        gap = (event.event_ts - groups[-1][-1].event_ts).total_seconds()
        if gap > inactivity_break_seconds:
            groups.append([event])
        else:
            groups[-1].append(event)
    sessions = []
    for group in groups:
        start, end = group[0].event_ts, group[-1].event_ts
        observed = max(0, int((end - start).total_seconds()))
        bounded = 0
        for a, b in zip(group, group[1:]):
            gap = max(0, int((b.event_ts - a.event_ts).total_seconds()))
            bounded += min(gap, max_credit_per_gap_seconds)
        sessions.append(ActivitySession(start, end, len(group), observed, bounded, f"gap_break={inactivity_break_seconds}s;gap_credit_cap={max_credit_per_gap_seconds}s"))
    return sessions
