from bgl.cli import main
main()
