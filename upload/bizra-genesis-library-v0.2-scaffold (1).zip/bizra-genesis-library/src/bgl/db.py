import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS objects (
    object_id TEXT PRIMARY KEY,
    sha256 TEXT NOT NULL UNIQUE,
    size_bytes INTEGER NOT NULL,
    storage_path TEXT NOT NULL,
    first_seen_at TEXT NOT NULL,
    integrity_state TEXT NOT NULL DEFAULT 'STORED'
);

CREATE TABLE IF NOT EXISTS source_locations (
    source_location_id TEXT PRIMARY KEY,
    object_id TEXT NOT NULL,
    provider TEXT NOT NULL,
    original_path TEXT NOT NULL,
    original_name TEXT NOT NULL,
    size_bytes INTEGER,
    source_modified_ns INTEGER,
    observed_at TEXT NOT NULL,
    UNIQUE(provider, original_path, object_id),
    FOREIGN KEY(object_id) REFERENCES objects(object_id)
);

CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    pipeline TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    source TEXT,
    observed_count INTEGER NOT NULL DEFAULT 0,
    unique_added INTEGER NOT NULL DEFAULT 0,
    duplicates_linked INTEGER NOT NULL DEFAULT 0,
    errors INTEGER NOT NULL DEFAULT 0,
    receipt_path TEXT
);

CREATE TABLE IF NOT EXISTS events (
    event_id TEXT PRIMARY KEY,
    run_id TEXT,
    object_id TEXT,
    stage TEXT NOT NULL,
    action TEXT NOT NULL,
    status TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    details_json TEXT,
    FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS actors (
    actor_id TEXT PRIMARY KEY,
    actor_type TEXT NOT NULL,
    display_alias TEXT NOT NULL,
    authority_state TEXT NOT NULL DEFAULT 'UNVERIFIED'
);

CREATE TABLE IF NOT EXISTS actor_identities (
    identity_id TEXT PRIMARY KEY,
    actor_id TEXT NOT NULL,
    provider TEXT NOT NULL,
    account_alias TEXT NOT NULL,
    evidence_ref TEXT,
    verification_state TEXT NOT NULL DEFAULT 'UNVERIFIED',
    UNIQUE(provider, account_alias),
    FOREIGN KEY(actor_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS activity_events (
    activity_event_id TEXT PRIMARY KEY,
    actor_id TEXT NOT NULL,
    identity_id TEXT,
    event_ts TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_ref TEXT NOT NULL,
    event_type TEXT NOT NULL,
    project_context TEXT,
    confidence REAL NOT NULL DEFAULT 1.0,
    FOREIGN KEY(actor_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS activity_sessions (
    session_id TEXT PRIMARY KEY,
    actor_id TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    start_ts TEXT NOT NULL,
    end_ts TEXT NOT NULL,
    event_count INTEGER NOT NULL,
    observed_span_seconds INTEGER NOT NULL,
    bounded_active_seconds INTEGER NOT NULL,
    method TEXT NOT NULL,
    confidence REAL NOT NULL,
    FOREIGN KEY(actor_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS contribution_items (
    contribution_id TEXT PRIMARY KEY,
    actor_id TEXT NOT NULL,
    object_id TEXT,
    contribution_class TEXT NOT NULL,
    evidence_state TEXT NOT NULL,
    rights_state TEXT NOT NULL DEFAULT 'UNKNOWN',
    verification_state TEXT NOT NULL DEFAULT 'UNVERIFIED',
    FOREIGN KEY(actor_id) REFERENCES actors(actor_id),
    FOREIGN KEY(object_id) REFERENCES objects(object_id)
);
"""

def connect(db_path: str | Path) -> sqlite3.Connection:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db(db_path: str | Path) -> None:
    with connect(db_path) as conn:
        conn.executescript(SCHEMA)
