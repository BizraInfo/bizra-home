from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

@dataclass(frozen=True)
class FileCandidate:
    path: Path
    size_bytes: int
    modified_ns: int

def discover(root: str | Path, follow_symlinks: bool = False) -> Iterator[FileCandidate]:
    root = Path(root).expanduser().resolve()
    for p in root.rglob("*"):
        try:
            if p.is_symlink() and not follow_symlinks:
                continue
            if not p.is_file():
                continue
            st = p.stat()
            yield FileCandidate(path=p, size_bytes=st.st_size, modified_ns=st.st_mtime_ns)
        except (OSError, PermissionError):
            continue
