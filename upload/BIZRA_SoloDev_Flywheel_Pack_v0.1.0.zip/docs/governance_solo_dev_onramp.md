# Governance: Solo-Dev Onramp (v0.1.0)

## Roles
- Maintainers: merge authority, sign receipts
- Reviewers: domain + security review
- Contributors: implement quests

## Review rubric (fast + strict)
1) Does the Quest acceptance tests pass?
2) Are truth labels accurate?
3) Any simulated components mislabeled as real?
4) Security posture improved or unchanged?
5) Any semantic drift vs Lexicon Ledger?

## Anti-Sybil for rewards
- small mints: open
- large mints: require trust tier + cooldown + extra reviewers
