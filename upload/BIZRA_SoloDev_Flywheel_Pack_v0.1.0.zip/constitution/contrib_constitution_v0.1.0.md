# BIZRA Contribution Constitution (v0.1.0)

## Truth Rule
Every Quest MUST include:
- `Truth:` label (MEASURED | CODE-VERIFIED | DESIGN-TARGET | PLANNED)
- explicit evidence hooks (paths, line refs, logs, receipts)

## Integrity Gate (minimum)
PR must pass:
- format + lint + tests
- secret scan
- truth-lint + portability-lint
- ihsan parity (if it touches scoring/constitution)
- lexicon lint (if it touches terms)

## “Sim vs Real” Rule
Any adapter, agent, or integration MUST declare:
- `AdapterMode: SIMULATED | REAL | MIXED`
and must not claim REAL unless it has verifiable evidence.

## Receipt Rule
Merged work MUST emit a PoI receipt, append-only, signed by:
- the maintainer key (Phase-0)
- later: quorum signers (Phase-1+)

## Reward Rule (token-agnostic)
Reward is computed from:
- impact magnitude
- ihsan score
- security criticality bonus/penalty
- network multiplier (when applicable)
- anti-sybil / trust constraints

All rewards are policy-controlled, not negotiated ad-hoc.
