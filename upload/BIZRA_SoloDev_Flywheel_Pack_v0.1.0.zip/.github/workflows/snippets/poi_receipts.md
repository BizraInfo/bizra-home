# CI snippet: add after your Phase-0 jobs
# - validate ImpactQuest JSON if you store quests as files
# - generate PoI receipt artifact on merge/tag
