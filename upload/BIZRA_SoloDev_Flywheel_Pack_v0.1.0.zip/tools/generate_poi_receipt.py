#!/usr/bin/env python3
"""Generate a minimal PoI receipt JSON.

This is intentionally simple; integrate signing later.
"""
import argparse, json, hashlib
from datetime import datetime, timezone

def rid(data: str) -> str:
    h = hashlib.sha256(data.encode('utf-8')).hexdigest().upper()
    return "R-" + h[:12]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quest-id", required=True)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--commit", required=True)
    ap.add_argument("--genesis-hash", required=True)
    ap.add_argument("--lexicon-hash", required=True)
    ap.add_argument("--sbom-hash", required=True)
    ap.add_argument("--ihsan-score", type=float, required=True)
    ap.add_argument("--vector-version", required=True)
    ap.add_argument("--truth-label", choices=["MEASURED","CODE-VERIFIED"], default="MEASURED")
    ap.add_argument("--tests-passed", action="store_true")
    ap.add_argument("--tests-summary", default="phase0 gates")
    ap.add_argument("--gitleaks-passed", action="store_true")
    ap.add_argument("--security-notes", default="")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    ts = datetime.now(timezone.utc).isoformat()
    receipt = {
        "receipt_id": rid(args.quest_id + args.commit + ts),
        "quest_id": args.quest_id,
        "truth_label": args.truth_label,
        "timestamp_utc": ts,
        "repo": args.repo,
        "commit": args.commit,
        "artifacts": {
            "genesis_hash": args.genesis_hash,
            "lexicon_hash": args.lexicon_hash,
            "sbom_hash": args.sbom_hash,
        },
        "ihsan": {
            "score": args.ihsan_score,
            "vector_version": args.vector_version,
        },
        "tests": {
            "passed": bool(args.tests_passed),
            "summary": args.tests_summary,
        },
        "security": {
            "gitleaks_passed": bool(args.gitleaks_passed),
            "notes": args.security_notes,
        },
        "signatures": [
            {"key_id":"__MAINTAINER__", "sig_alg":"ed25519", "signature":"__PENDING__"}
        ]
    }

    with open(args.out, "w", encoding="utf-8", newline="\n") as f:
        json.dump(receipt, f, indent=2, sort_keys=True)
        f.write("\n")

if __name__ == "__main__":
    main()
