#!/usr/bin/env python3
"""A tiny 'truth label' lint for docs.

Rules:
- A doc must include a line starting with 'Truth:' within first 20 lines.
- Allowed values: MEASURED | CODE-VERIFIED | DESIGN-TARGET | PLANNED
"""
import argparse, sys, re, pathlib

ALLOWED = {"MEASURED","CODE-VERIFIED","DESIGN-TARGET","PLANNED"}

def check(path: pathlib.Path) -> int:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    head = lines[:20]
    for ln in head:
        m = re.match(r"^Truth:\s*(.+)\s*$", ln.strip())
        if m:
            val = m.group(1).strip()
            if val in ALLOWED:
                return 0
            return 2
    return 1

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    args = ap.parse_args()
    rc = 0
    for p in args.paths:
        path = pathlib.Path(p)
        if path.is_dir():
            for f in path.rglob("*.md"):
                rc = max(rc, check(f))
        else:
            rc = max(rc, check(path))
    if rc == 0:
        print("[OK] truth labels present")
        return
    if rc == 1:
        print("[FAIL] missing Truth: label in one or more files")
    else:
        print("[FAIL] invalid Truth: label value in one or more files")
    sys.exit(1)

if __name__ == "__main__":
    main()
