# BIZRA Solo-Developer Flywheel Pack (v0.1.0)

This pack is a *drop-in* spec + repo scaffolding to let solo developers contribute to BIZRA with:
- **Truth-first** docs
- **CI-enforced integrity gates** (Phase-0 style)
- **Quest-based contribution workflow** (MMORPG-like “Impact Quests”)
- **PoI receipts** (append-only, auditable)
- **Reward calculation inputs** (token-agnostic; binds to your Lexicon Ledger)

## What this enables

1) A developer picks a Quest (feature, fix, hardening, product module).
2) They implement in a branch, open a PR.
3) CI runs: integrity gates + truth-lints + security scans.
4) On merge, a **PoI Receipt** is generated & signed.
5) Reward policy mints utility tokens per constitution *after* verification.

> NOTE: Token symbols are intentionally placeholders. Bind them via your Lexicon Ledger
> (e.g., SEED/BLOOM or BZT/BZC) to avoid semantic drift.

## Folder overview

- `constitution/`     : contribution constitution + reward policy inputs
- `schemas/`          : Quest + Receipt JSON Schemas
- `tools/`            : receipt generator & lints (reference implementations)
- `.github/`          : issue templates (Quest intake) + suggested CI job blocks
- `docs/`             : governance + anti-sybil + reviewer rubric

## Minimal adoption steps (20 minutes)

1. Copy this pack into your repo under `.bizra/contrib/`
2. Add GitHub Issue Forms for Quests from `.github/ISSUE_TEMPLATE/`
3. Add the CI job snippet from `.github/workflows/snippets/`
4. Require: Quest Issue -> PR -> Receipt

